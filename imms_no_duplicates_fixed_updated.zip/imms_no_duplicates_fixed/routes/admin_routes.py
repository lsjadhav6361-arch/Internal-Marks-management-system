from __future__ import annotations

from functools import wraps
from io import BytesIO, StringIO
import csv
import zipfile
from datetime import datetime

import pandas as pd
from flask import Blueprint, flash, redirect, render_template, request, send_file, session, url_for

from database.db import fetch_all, fetch_one, get_db
from mysql.connector import IntegrityError
from utils.auth import hash_password, verify_password
from utils.excel_handler import (
    build_academic_year_template,
    build_course_template,
    build_student_template,
    build_subject_template,
    build_teacher_template,
    normalize_student_dataframe,
)

admin = Blueprint('admin', __name__, url_prefix='/admin')


def login_required(view_func):
    @wraps(view_func)
    def wrapped_view(*args, **kwargs):
        if session.get('user_role') not in {'admin', 'hod'}:
            flash('Please log in first', 'warning')
            return redirect(url_for('login'))
        return view_func(*args, **kwargs)
    return wrapped_view


@admin.app_context_processor
def inject_session_user():
    role = (session.get('user_role') or 'guest').upper()
    display_name = session.get('display_name') or 'Guest'
    profile_letter = display_name[:1].upper() if display_name else 'G'
    return {
        'session_role_label': role,
        'session_display_name': display_name,
        'session_profile_letter': profile_letter,
    }




def _flash_duplicate_or_saved(entity_label: str, duplicate_count: int = 0, inserted_count: int = 0, updated_count: int = 0):
    parts = []
    if inserted_count:
        parts.append(f"Added {inserted_count} new {entity_label}.")
    if updated_count:
        parts.append(f"Updated {updated_count} existing {entity_label}.")
    if duplicate_count:
        plural = 's' if duplicate_count != 1 else ''
        parts.append(f"{duplicate_count} {entity_label}{plural} already exist and were not added again.")
    if parts:
        category = 'warning' if duplicate_count and not inserted_count and not updated_count else 'success'
        flash(' '.join(parts), category)

def _delete_by_id(table: str, row_id: int):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute(f'DELETE FROM {table} WHERE id = %s', (row_id,))
        conn.commit()
        affected = cursor.rowcount
        cursor.close()
    return affected


# -----------------------------------------------------------------------------
# Data backup for Admin/HOD
#
# This route allows administrators and HODs to download a complete backup of
# the application's database tables.  The backup consists of a ZIP archive
# containing a CSV file for each table.  Only users with the ``admin`` or
# ``hod`` role may access this endpoint.  The ZIP filename includes a
# timestamp to avoid name collisions.  The list of tables to export is
# explicitly defined to prevent accidental exposure of unwanted data.

@admin.route('/backup-data', methods=['GET'])
@login_required
def backup_data():
    """Generate and return a ZIP archive containing CSV backups of all tables.

    The backup functionality is limited to administrators and HOD users.  When
    invoked, it will fetch all records from each table listed in
    ``tables_to_backup``, convert them into CSV format using pandas, and write
    them into an in-memory ZIP file.  The resulting archive is returned as a
    downloadable attachment.  If a table is empty, an empty CSV (with no
    rows) is still created to ensure the table is represented in the backup.
    """
    # Restrict access to admin and HOD users only
    if session.get('user_role') not in {'admin', 'hod'}:
        flash('Access denied.', 'error')
        return redirect(url_for('admin.dashboard'))

    # Explicitly list the tables that should be included in the backup.  This
    # helps to avoid exporting unintended tables (e.g. session tables) and
    # provides a clear record of what data is backed up.  If new tables are
    # added to the schema, append them here.
    tables_to_backup = [
        'users',
        'academic_years',
        'courses',
        'teachers',
        'subjects',
        'teacher_allocations',
        'students',
        'ia_settings',
        'internal_marks',
        'student_queries',
    ]

    # Create an in-memory bytes buffer to hold the ZIP archive
    zip_buffer = BytesIO()
    with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zf:
        with get_db() as conn:
            for table in tables_to_backup:
                cursor = conn.cursor(dictionary=True)
                try:
                    cursor.execute(f'SELECT * FROM `{table}`')
                    rows = cursor.fetchall() or []
                    # Convert rows to a DataFrame; this handles empty tables
                    df = pd.DataFrame(rows)
                    # Write CSV to string (no index)
                    csv_data = df.to_csv(index=False)
                    # Ensure each CSV entry has at least a header row.  If
                    # ``df`` is empty but we have column names from the cursor,
                    # construct a header string manually.
                    if df.empty and cursor.column_names:
                        header_line = ','.join(cursor.column_names) + '\n'
                        csv_data = header_line
                    # Use the table name as the file name within the ZIP
                    zf.writestr(f'{table}.csv', csv_data)
                finally:
                    cursor.close()

    # Prepare the ZIP file for download.  The timestamp ensures unique
    # filenames and helps identify when the backup was taken.
    zip_buffer.seek(0)
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    return send_file(
        zip_buffer,
        mimetype='application/zip',
        as_attachment=True,
        download_name=f'imms_backup_{timestamp}.zip'
    )


# -----------------------------------------------------------------------------
# Profile management for Admin/HOD
#
# This route allows administrators and HODs to update their own login
# credentials.  Users must supply their current password for verification.
# Changing the username (email) is optional but must be unique among
# administrators.  If a new password is provided, it is hashed before
# storing.  Display names are not modified here.

@admin.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    # Only admin and HOD users can access this page
    if session.get('user_role') not in {'admin', 'hod'}:
        flash('Access denied.', 'error')
        return redirect(url_for('admin.dashboard'))

    user_id = session.get('user_id')
    if not user_id:
        flash('User session invalid.', 'error')
        return redirect(url_for('login'))

    # Fetch current user details
    user = fetch_one('SELECT id, username, password, role, display_name FROM users WHERE id = %s', (user_id,))
    if not user:
        flash('User account not found.', 'error')
        return redirect(url_for('login'))

    if request.method == 'POST':
        # Normalise inputs
        current_password = (request.form.get('current_password') or '').strip()
        new_username = (request.form.get('new_username') or '').strip().lower()
        new_password = (request.form.get('new_password') or '').strip()
        confirm_password = (request.form.get('confirm_password') or '').strip()

        # Validate presence of current password
        if not current_password:
            flash('Please provide your current password.', 'error')
            return redirect(url_for('admin.profile'))

        # Validate password length if provided
        if new_password and len(new_password) < 6:
            flash('New password must be at least 6 characters.', 'error')
            return redirect(url_for('admin.profile'))

        # Validate password confirmation
        if new_password and new_password != confirm_password:
            flash('New password and confirm password do not match.', 'error')
            return redirect(url_for('admin.profile'))

        # Verify current password using the stored hash
        if not verify_password(user['password'], current_password):
            flash('Current password is incorrect.', 'error')
            return redirect(url_for('admin.profile'))

        # If the username is being changed, ensure uniqueness among admins/HODs
        if new_username and new_username != user['username']:
            # Check for duplicates
            existing = fetch_one('SELECT id FROM users WHERE username = %s AND id <> %s AND role IN ("admin", "hod")', (new_username, user_id))
            if existing:
                flash('The provided email/username is already in use.', 'error')
                return redirect(url_for('admin.profile'))
        else:
            new_username = user['username']

        # Compute the new password hash; if no new password provided, keep existing
        updated_password = hash_password(new_password) if new_password else user['password']

        # Persist changes
        with get_db() as conn:
            cursor = conn.cursor()
            cursor.execute(
                'UPDATE users SET username = %s, password = %s WHERE id = %s',
                (new_username, updated_password, user_id)
            )
            conn.commit(); cursor.close()

        # Update session data
        session['user_id'] = user_id
        session['user_role'] = user['role']
        session['display_name'] = user['display_name']
        flash('Profile updated successfully.', 'success')
        return redirect(url_for('admin.profile'))

    return render_template('admin/change_credentials.html', user=user)


@admin.route('/dashboard')
@login_required
def dashboard():
    stats = {
        'students': fetch_one('SELECT COUNT(*) AS total FROM students')['total'],
        'teachers': fetch_one('SELECT COUNT(*) AS total FROM teachers')['total'],
        'subjects': fetch_one('SELECT COUNT(*) AS total FROM subjects')['total'],
        'academic_years': fetch_one('SELECT COUNT(*) AS total FROM academic_years')['total'],
        'allocations': fetch_one('SELECT COUNT(*) AS total FROM teacher_allocations')['total'],
        'marks_entries': fetch_one('SELECT COUNT(*) AS total FROM internal_marks')['total'],
    }
    recent_ia = fetch_all(
        '''
        SELECT academic_year, course, semester, assignment_max, ia1_max, ia1_convert_to, ia2_max, ia2_convert_to, total_marks
        FROM ia_settings
        ORDER BY updated_at DESC, academic_year DESC, course ASC, semester ASC
        LIMIT 5
        '''
    )
    return render_template('admin/dashboard.html', stats=stats, recent_ia=recent_ia)


@admin.route('/academic-years', methods=['GET', 'POST'])
@login_required
def academic_years():
    if request.method == 'POST':
        label = request.form.get('label', '').strip()
        if not label:
            flash('Academic year is required.', 'error')
            return redirect(url_for('admin.academic_years'))
        with get_db() as conn:
            cursor = conn.cursor(dictionary=True)
            cursor.execute('SELECT id FROM academic_years WHERE label = %s', (label,))
            existing = cursor.fetchone()
            if existing:
                cursor.close()
                flash('Academic year already exists.', 'warning')
                return redirect(url_for('admin.academic_years'))
            cursor.close()

            cursor = conn.cursor()
            cursor.execute('INSERT INTO academic_years (label) VALUES (%s)', (label,))
            conn.commit()
            cursor.close()
        flash('Academic year saved successfully.', 'success')
        return redirect(url_for('admin.academic_years'))
    rows = fetch_all('SELECT * FROM academic_years ORDER BY label DESC')
    return render_template('admin/academic_years.html', years=rows)


@admin.route('/academic-years/edit/<int:year_id>', methods=['GET', 'POST'])
@login_required
def edit_academic_year(year_id):
    row = fetch_one('SELECT * FROM academic_years WHERE id = %s', (year_id,))
    if not row:
        flash('Academic year not found.', 'error')
        return redirect(url_for('admin.academic_years'))
    if request.method == 'POST':
        label = request.form.get('label', '').strip()
        is_active = 1 if request.form.get('is_active') == '1' else 0
        if not label:
            flash('Academic year is required.', 'error')
            return redirect(url_for('admin.edit_academic_year', year_id=year_id))
        with get_db() as conn:
            cursor = conn.cursor()
            cursor.execute('UPDATE academic_years SET label = %s, is_active = %s WHERE id = %s', (label, is_active, year_id))
            conn.commit()
            cursor.close()
        flash('Academic year updated successfully.', 'success')
        return redirect(url_for('admin.academic_years'))
    return render_template('admin/edit_academic_year.html', row=row)


@admin.route('/academic-years/delete/<int:year_id>')
@login_required
def delete_academic_year(year_id):
    try:
        affected = _delete_by_id('academic_years', year_id)
        flash('Academic year deleted.' if affected else 'Academic year not found.', 'success' if affected else 'warning')
    except Exception as exc:
        flash(f'Could not delete academic year: {exc}', 'error')
    return redirect(url_for('admin.academic_years'))


@admin.route('/courses', methods=['GET', 'POST'])
@login_required
def courses():
    if request.method == 'POST':
        form_type = request.form.get('form_type', '').strip()
        if form_type == 'course':
            course_name = request.form.get('course_name', '').strip()
            if not course_name:
                flash('Course name is required.', 'error')
                return redirect(url_for('admin.courses'))
            with get_db() as conn:
                cursor = conn.cursor(dictionary=True)
                cursor.execute('SELECT id FROM courses WHERE LOWER(course_name) = LOWER(%s)', (course_name,))
                existing = cursor.fetchone()
                if existing:
                    cursor.close()
                    flash('Course already exists.', 'warning')
                    return redirect(url_for('admin.courses'))
                cursor.close()

                cursor = conn.cursor()
                cursor.execute('INSERT INTO courses (course_name) VALUES (%s)', (course_name,))
                conn.commit()
                cursor.close()
            flash('Course saved successfully.', 'success')
            return redirect(url_for('admin.courses'))
        if form_type == 'subject':
            academic_year = request.form.get('academic_year', '').strip()
            course = request.form.get('course', '').strip()
            semester = request.form.get('semester', type=int)
            subject_code = request.form.get('subject_code', '').strip()
            subject_name = request.form.get('subject_name', '').strip()
            subject_type = request.form.get('subject_type', 'theory').strip()
            if not academic_year or not course or not semester or not subject_name:
                flash('Please fill all required subject fields.', 'error')
                return redirect(url_for('admin.courses'))
            with get_db() as conn:
                cursor = conn.cursor(dictionary=True)
                cursor.execute('''
                    SELECT id FROM subjects
                    WHERE academic_year = %s AND course = %s AND semester = %s AND LOWER(subject_name) = LOWER(%s)
                ''', (academic_year, course, semester, subject_name))
                existing = cursor.fetchone()
                if existing:
                    cursor.close()
                    flash('Subject already exists for the selected academic year, course, and semester.', 'warning')
                    return redirect(url_for('admin.courses'))
                cursor.close()

                cursor = conn.cursor()
                cursor.execute('''
                    INSERT INTO subjects
                    (academic_year, course, semester, subject_code, subject_name, subject_type)
                    VALUES (%s, %s, %s, %s, %s, %s)
                ''', (academic_year, course, semester, subject_code, subject_name, subject_type))
                conn.commit()
                cursor.close()
            flash('Subject saved successfully.', 'success')
            return redirect(url_for('admin.courses'))
    return render_template('admin/courses.html', courses=fetch_all('SELECT * FROM courses ORDER BY course_name ASC'), academic_years=fetch_all('SELECT label FROM academic_years ORDER BY label DESC'), subjects=fetch_all('SELECT * FROM subjects ORDER BY academic_year DESC, course ASC, semester ASC, subject_name ASC'))


@admin.route('/courses/edit/<int:course_id>', methods=['GET', 'POST'])
@login_required
def edit_course(course_id):
    row = fetch_one('SELECT * FROM courses WHERE id = %s', (course_id,))
    if not row:
        flash('Course not found.', 'error')
        return redirect(url_for('admin.courses'))
    if request.method == 'POST':
        course_name = request.form.get('course_name', '').strip()
        is_active = 1 if request.form.get('is_active') == '1' else 0
        if not course_name:
            flash('Course name is required.', 'error')
            return redirect(url_for('admin.edit_course', course_id=course_id))
        with get_db() as conn:
            cursor = conn.cursor()
            cursor.execute('UPDATE courses SET course_name = %s, is_active = %s WHERE id = %s', (course_name, is_active, course_id))
            conn.commit()
            cursor.close()
        flash('Course updated successfully.', 'success')
        return redirect(url_for('admin.courses'))
    return render_template('admin/edit_course.html', row=row)


@admin.route('/courses/delete/<int:course_id>')
@login_required
def delete_course(course_id):
    try:
        affected = _delete_by_id('courses', course_id)
        flash('Course deleted.' if affected else 'Course not found.', 'success' if affected else 'warning')
    except Exception as exc:
        flash(f'Could not delete course: {exc}', 'error')
    return redirect(url_for('admin.courses'))


@admin.route('/subjects', methods=['GET', 'POST'])
@login_required
def subjects():
    if request.method == 'POST':
        academic_year = request.form.get('academic_year', '').strip()
        course = request.form.get('course', '').strip()
        semester = request.form.get('semester', type=int)
        subject_name = request.form.get('subject_name', '').strip()
        subject_code = request.form.get('subject_code', '').strip()
        subject_type = request.form.get('subject_type', 'theory').strip()
        if not all([academic_year, course, semester, subject_name]):
            flash('Academic year, course, semester and subject name are required.', 'error')
            return redirect(url_for('admin.subjects'))
        with get_db() as conn:
            cursor = conn.cursor(dictionary=True)
            cursor.execute('''
                SELECT id FROM subjects
                WHERE academic_year = %s AND course = %s AND semester = %s AND LOWER(subject_name) = LOWER(%s)
            ''', (academic_year, course, semester, subject_name))
            existing = cursor.fetchone()
            if existing:
                cursor.close()
                flash('Subject already exists for the selected academic year, course, and semester.', 'warning')
                return redirect(url_for('admin.subjects'))
            cursor.close()

            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO subjects (academic_year, course, semester, subject_code, subject_name, subject_type)
                VALUES (%s, %s, %s, %s, %s, %s)
            ''', (academic_year, course, semester, subject_code, subject_name, subject_type))
            conn.commit()
            cursor.close()
        flash('Subject saved successfully.', 'success')
        return redirect(url_for('admin.subjects'))
    return render_template('admin/subjects.html', subjects=fetch_all('SELECT * FROM subjects ORDER BY academic_year DESC, course ASC, semester ASC, subject_name ASC'), academic_years=fetch_all('SELECT label FROM academic_years ORDER BY label DESC'), courses=fetch_all('SELECT course_name FROM courses ORDER BY course_name ASC'))


@admin.route('/subjects/edit/<int:subject_id>', methods=['GET', 'POST'])
@login_required
def edit_subject(subject_id):
    row = fetch_one('SELECT * FROM subjects WHERE id = %s', (subject_id,))
    if not row:
        flash('Subject not found.', 'error')
        return redirect(url_for('admin.subjects'))
    if request.method == 'POST':
        academic_year = request.form.get('academic_year', '').strip()
        course = request.form.get('course', '').strip()
        semester = request.form.get('semester', type=int)
        subject_code = request.form.get('subject_code', '').strip()
        subject_name = request.form.get('subject_name', '').strip()
        subject_type = request.form.get('subject_type', 'theory').strip()
        if not all([academic_year, course, semester, subject_name]):
            flash('Please fill all required fields.', 'error')
            return redirect(url_for('admin.edit_subject', subject_id=subject_id))
        with get_db() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE subjects SET academic_year = %s, course = %s, semester = %s, subject_code = %s, subject_name = %s, subject_type = %s WHERE id = %s
            ''', (academic_year, course, semester, subject_code, subject_name, subject_type, subject_id))
            conn.commit()
            cursor.close()
        flash('Subject updated successfully.', 'success')
        return redirect(url_for('admin.subjects'))
    return render_template('admin/edit_subject.html', row=row, academic_years=fetch_all('SELECT label FROM academic_years ORDER BY label DESC'), courses=fetch_all('SELECT course_name FROM courses ORDER BY course_name ASC'))


@admin.route('/subjects/delete/<int:subject_id>')
@login_required
def delete_subject(subject_id):
    try:
        affected = _delete_by_id('subjects', subject_id)
        flash('Subject deleted.' if affected else 'Subject not found.', 'success' if affected else 'warning')
    except Exception as exc:
        flash(f'Could not delete subject: {exc}', 'error')
    return redirect(url_for('admin.subjects'))


@admin.route('/teachers', methods=['GET', 'POST'])
@login_required
def teachers():
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip().lower()
        phone = request.form.get('phone', '').strip()
        qualification = request.form.get('qualification', '').strip()
        experience = request.form.get('experience', '').strip()
        notes = request.form.get('notes', '').strip()
        if not all([name, email]):
            flash('Please fill teacher name and email.', 'error')
            return redirect(url_for('admin.teachers'))
        # Prevent duplicate teacher creation by checking existing email
        with get_db() as conn:
            cursor = conn.cursor(dictionary=True)
            cursor.execute('SELECT id FROM teachers WHERE email = %s', (email,))
            existing = cursor.fetchone()
            if existing:
                cursor.close()
                flash('A teacher with this email already exists. Please edit the teacher instead.', 'error')
                return redirect(url_for('admin.teachers'))
            # Generate a hashed default password.  If a phone number was
            # provided, use it as the initial password; otherwise fall back
            # to a project default.  Admin/HOD can later reset it.
            initial_plain = phone or 'demo123'
            hashed_pw = hash_password(initial_plain)
            cursor.execute(
                '''INSERT INTO teachers (name, email, password, phone, qualification, experience, notes) VALUES (%s, %s, %s, %s, %s, %s, %s)''',
                (name, email, hashed_pw, phone, qualification, experience, notes)
            )
            conn.commit(); cursor.close()
        flash('Teacher created successfully. Use Allocations to map subjects.', 'success')
        return redirect(url_for('admin.teachers'))
    teacher_rows = fetch_all('''
        SELECT t.*,
               (
                   SELECT CONCAT(ta.academic_year, ' / ', ta.course, ' / Sem ', ta.semester, ' / ', ta.subject_name)
                   FROM teacher_allocations ta
                   WHERE ta.teacher_id = t.id
                   ORDER BY ta.id DESC
                   LIMIT 1
               ) AS latest_allocation,
               (
                   SELECT COUNT(*) FROM teacher_allocations ta WHERE ta.teacher_id = t.id
               ) AS allocation_count
        FROM teachers t
        ORDER BY t.name ASC
    ''')
    return render_template('admin/teachers.html', teachers=teacher_rows)



@admin.route('/teachers/edit/<int:teacher_id>', methods=['GET', 'POST'])
@login_required
def edit_teacher(teacher_id):
    row = fetch_one('SELECT * FROM teachers WHERE id = %s', (teacher_id,))
    if not row:
        flash('Teacher not found.', 'error')
        return redirect(url_for('admin.teachers'))
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip().lower()
        phone = request.form.get('phone', '').strip()
        qualification = request.form.get('qualification', '').strip()
        experience = request.form.get('experience', '').strip()
        notes = request.form.get('notes', '').strip()
        if not name or not email:
            flash('Name and email are required.', 'error')
            return redirect(url_for('admin.edit_teacher', teacher_id=teacher_id))
        with get_db() as conn:
            cursor = conn.cursor(dictionary=True)
            # Disallow changing the email to one that belongs to another teacher
            cursor.execute('SELECT id FROM teachers WHERE email = %s AND id <> %s', (email, teacher_id))
            duplicate = cursor.fetchone()
            if duplicate:
                cursor.close()
                flash('Another teacher with this email already exists.', 'error')
                return redirect(url_for('admin.edit_teacher', teacher_id=teacher_id))
            cursor.execute(
                '''UPDATE teachers SET name = %s, email = %s, phone = %s, qualification = %s, experience = %s, notes = %s WHERE id = %s''',
                (name, email, phone, qualification, experience, notes, teacher_id)
            )
            conn.commit(); cursor.close()
        flash('Teacher updated successfully.', 'success')
        return redirect(url_for('admin.teachers'))
    allocations = fetch_all('SELECT * FROM teacher_allocations WHERE teacher_id = %s ORDER BY academic_year DESC, course ASC, semester ASC', (teacher_id,))
    return render_template('admin/edit_teacher.html', row=row, allocations=allocations)


@admin.route('/teachers/delete/<int:teacher_id>')
@login_required
def delete_teacher(teacher_id):
    try:
        affected = _delete_by_id('teachers', teacher_id)
        flash('Teacher deleted.' if affected else 'Teacher not found.', 'success' if affected else 'warning')
    except Exception as exc:
        flash(f'Could not delete teacher: {exc}', 'error')
    return redirect(url_for('admin.teachers'))


@admin.route('/teachers/reset-password/<int:teacher_id>', methods=['GET', 'POST'])
@login_required
def reset_teacher_password(teacher_id: int):
    """Allow an Admin/HOD to reset a teacher's password.

    A new password can be set for the selected teacher.  The new password
    must be at least six characters long and confirmed via a form.  The
    password is stored as a salted hash.
    """
    # Fetch teacher basic details
    teacher = fetch_one('SELECT id, name, email FROM teachers WHERE id = %s', (teacher_id,))
    if not teacher:
        flash('Teacher not found.', 'error')
        return redirect(url_for('admin.teachers'))

    if request.method == 'POST':
        new_password = (request.form.get('new_password') or '').strip()
        confirm_password = (request.form.get('confirm_password') or '').strip()
        if not new_password or not confirm_password:
            flash('Please provide and confirm the new password.', 'error')
            return redirect(url_for('admin.reset_teacher_password', teacher_id=teacher_id))
        if len(new_password) < 6:
            flash('Password must be at least 6 characters.', 'error')
            return redirect(url_for('admin.reset_teacher_password', teacher_id=teacher_id))
        if new_password != confirm_password:
            flash('Passwords do not match.', 'error')
            return redirect(url_for('admin.reset_teacher_password', teacher_id=teacher_id))

        # Hash and update the password
        hashed_pw = hash_password(new_password)
        with get_db() as conn:
            cursor = conn.cursor()
            cursor.execute('UPDATE teachers SET password = %s WHERE id = %s', (hashed_pw, teacher_id))
            conn.commit(); cursor.close()
        flash(f"Password for {teacher['name']} has been reset.", 'success')
        return redirect(url_for('admin.edit_teacher', teacher_id=teacher_id))

    return render_template('admin/reset_teacher_password.html', teacher=teacher)


@admin.route('/teachers/upload-excel', methods=['POST'])
@login_required
def upload_teacher_excel():
    file = request.files.get('file')
    if not file or file.filename == '':
        flash('Please choose a teacher Excel file.', 'error')
        return redirect(url_for('admin.teachers'))
    try:
        df = pd.read_excel(file)
        df.columns = [str(col).strip().lower().replace(' ', '_') for col in df.columns]
        inserted = 0
        updated = 0
        skipped = 0
        with get_db() as conn:
            cursor = conn.cursor(dictionary=True)
            for _, row in df.iterrows():
                name = str(row.get('name', '')).strip()
                email = str(row.get('email', '')).strip().lower()
                phone = str(row.get('phone', '')).strip()
                qualification = str(row.get('qualification', '')).strip()
                experience = str(row.get('experience', '')).strip()
                notes = str(row.get('notes', '')).strip()
                if not name or not email or email == 'nan':
                    skipped += 1
                    continue
                cursor.execute('SELECT id FROM teachers WHERE email = %s', (email,))
                existing = cursor.fetchone()
                if existing:
                    cursor.execute(
                        '''UPDATE teachers SET name=%s, phone=%s, qualification=%s, experience=%s, notes=%s WHERE email=%s''',
                        (name, phone, qualification, experience, notes, email)
                    )
                    updated += 1
                else:
                    # Hash the initial password: use phone if provided else fall back to 'demo123'
                    from utils.auth import hash_password
                    initial_plain = phone or 'demo123'
                    hashed_pw = hash_password(initial_plain)
                    cursor.execute(
                        '''INSERT INTO teachers (name, email, password, phone, qualification, experience, notes) VALUES (%s,%s,%s,%s,%s,%s,%s)''',
                        (name, email, hashed_pw, phone, qualification, experience, notes)
                    )
                    inserted += 1
            conn.commit(); cursor.close()
        _flash_duplicate_or_saved('teacher', duplicate_count=updated, inserted_count=inserted)
        if skipped:
            flash(f'{skipped} teacher rows were skipped because required values were missing.', 'warning')
    except Exception as exc:
        flash(f'Teacher upload failed: {exc}', 'error')
    return redirect(url_for('admin.teachers'))


@admin.route('/allocations', methods=['GET', 'POST'])
@login_required
def allocations():
    if request.method == 'POST':
        teacher_id = request.form.get('teacher_id', type=int)
        academic_year = request.form.get('academic_year', '').strip()
        course = request.form.get('course', '').strip()
        semester = request.form.get('semester', type=int)
        subject_names = [name.strip() for name in request.form.getlist('subject_names') if name.strip()]
        if not all([teacher_id, academic_year, course, semester]) or not subject_names:
            flash('Please select teacher, year, course, one semester, and at least one subject.', 'error')
            return redirect(url_for('admin.allocations'))

        with get_db() as conn:
            cursor = conn.cursor(dictionary=True)
            cursor.execute('''
                SELECT subject_name
                FROM subjects
                WHERE academic_year = %s AND course = %s AND semester = %s
            ''', (academic_year, course, semester))
            valid_subjects = {row['subject_name'] for row in cursor.fetchall()}

            cursor.execute('''
                SELECT ta.subject_name, t.name AS teacher_name
                FROM teacher_allocations ta
                JOIN teachers t ON t.id = ta.teacher_id
                WHERE ta.academic_year = %s AND ta.course = %s AND ta.semester = %s AND ta.teacher_id <> %s
            ''', (academic_year, course, semester, teacher_id))
            occupied_rows = cursor.fetchall()
            occupied_subjects = {row['subject_name']: row['teacher_name'] for row in occupied_rows}

            unavailable = [
                f"{subject_name} (already allocated to {occupied_subjects[subject_name]})"
                for subject_name in subject_names
                if subject_name in occupied_subjects
            ]
            invalid = [subject_name for subject_name in subject_names if subject_name not in valid_subjects]

            if invalid:
                cursor.close()
                flash('Some selected subjects are invalid for the chosen year, course, or semester.', 'error')
                return redirect(url_for('admin.allocations'))

            if unavailable:
                cursor.close()
                flash('These subjects are not available: ' + ', '.join(unavailable), 'error')
                return redirect(url_for('admin.allocations'))

            for subject_name in subject_names:
                cursor.execute('''
                    INSERT INTO teacher_allocations (teacher_id, academic_year, course, semester, subject_name)
                    VALUES (%s, %s, %s, %s, %s)
                ''', (teacher_id, academic_year, course, semester, subject_name))
            conn.commit()
            cursor.close()

        flash('Teacher allocation saved successfully.', 'success')
        return redirect(url_for('admin.allocations'))

    allocation_groups = fetch_all('''
        SELECT t.name AS teacher_name, ta.teacher_id, ta.academic_year, ta.course, ta.semester,
               GROUP_CONCAT(ta.subject_name ORDER BY ta.subject_name SEPARATOR ' || ') AS subject_names
        FROM teacher_allocations ta
        JOIN teachers t ON t.id = ta.teacher_id
        GROUP BY ta.teacher_id, ta.academic_year, ta.course, ta.semester
        ORDER BY ta.academic_year DESC, ta.course ASC, ta.semester ASC, t.name ASC
    ''')
    subjects = fetch_all('''
        SELECT s.academic_year, s.course, s.semester, s.subject_name,
               CASE WHEN ta.subject_name IS NULL THEN 0 ELSE 1 END AS is_allocated,
               t.name AS allocated_teacher
        FROM subjects s
        LEFT JOIN teacher_allocations ta
            ON ta.academic_year = s.academic_year
           AND ta.course = s.course
           AND ta.semester = s.semester
           AND ta.subject_name = s.subject_name
        LEFT JOIN teachers t ON t.id = ta.teacher_id
        ORDER BY s.academic_year DESC, s.course ASC, s.semester ASC, s.subject_name ASC
    ''')
    return render_template(
        'admin/allocations.html',
        allocation_groups=allocation_groups,
        teachers=fetch_all('SELECT id, name FROM teachers ORDER BY name ASC'),
        academic_years=fetch_all('SELECT label FROM academic_years ORDER BY label DESC'),
        courses=fetch_all('SELECT course_name FROM courses ORDER BY course_name ASC'),
        subjects=subjects,
    )



@admin.route('/allocations/edit/<int:allocation_id>', methods=['GET', 'POST'])
@login_required
def edit_allocation(allocation_id):
    row = fetch_one('SELECT * FROM teacher_allocations WHERE id = %s', (allocation_id,))
    if not row:
        flash('Allocation not found.', 'error')
        return redirect(url_for('admin.allocations'))
    if request.method == 'POST':
        teacher_id = request.form.get('teacher_id', type=int)
        academic_year = request.form.get('academic_year', '').strip()
        course = request.form.get('course', '').strip()
        semester = request.form.get('semester', type=int)
        subject_name = request.form.get('subject_name', '').strip()
        if not all([teacher_id, academic_year, course, semester, subject_name]):
            flash('Please fill all allocation fields.', 'error')
            return redirect(url_for('admin.edit_allocation', allocation_id=allocation_id))
        with get_db() as conn:
            cursor = conn.cursor()
            cursor.execute('''UPDATE teacher_allocations SET teacher_id = %s, academic_year = %s, course = %s, semester = %s, subject_name = %s WHERE id = %s''', (teacher_id, academic_year, course, semester, subject_name, allocation_id))
            conn.commit()
            cursor.close()
        flash('Allocation updated successfully.', 'success')
        return redirect(url_for('admin.allocations'))
    return render_template('admin/edit_allocation.html', row=row, teachers=fetch_all('SELECT id, name FROM teachers ORDER BY name ASC'), academic_years=fetch_all('SELECT label FROM academic_years ORDER BY label DESC'), courses=fetch_all('SELECT course_name FROM courses ORDER BY course_name ASC'), subjects=fetch_all('SELECT subject_name FROM subjects ORDER BY subject_name ASC'))


@admin.route('/allocations/delete/<int:allocation_id>')
@login_required
def delete_allocation(allocation_id):
    try:
        affected = _delete_by_id('teacher_allocations', allocation_id)
        flash('Allocation deleted.' if affected else 'Allocation not found.', 'success' if affected else 'warning')
    except Exception as exc:
        flash(f'Could not delete allocation: {exc}', 'error')
    return redirect(url_for('admin.allocations'))


@admin.route('/ia-settings', methods=['GET', 'POST'])
@login_required
def ia_settings():
    if request.method == 'POST':
        academic_year = request.form.get('academic_year', '').strip()
        course = request.form.get('course', '').strip()
        semester = request.form.get('semester', type=int)
        assignment_max = request.form.get('assignment_max', type=float) or 0
        ia1_max = request.form.get('ia1_max', type=float) or 0
        ia1_convert_to = request.form.get('ia1_convert_to', type=float) or 0
        ia2_max = request.form.get('ia2_max', type=float) or 0
        ia2_convert_to = request.form.get('ia2_convert_to', type=float) or 0
        practical_count = request.form.get('practical_count', type=int) or 0
        practical_max = request.form.get('practical_max', type=float) or 0
        total_marks = request.form.get('total_marks', type=float) or 0
        practical_enabled = 1 if practical_count > 0 else 0
        if not all([academic_year, course, semester]):
            flash('Academic year, course and semester are required for IA settings.', 'error')
            return redirect(url_for('admin.ia_settings'))
        with get_db() as conn:
            cursor = conn.cursor(dictionary=True)
            cursor.execute('SELECT id FROM ia_settings WHERE academic_year = %s AND course = %s AND semester = %s', (academic_year, course, semester))
            existing = cursor.fetchone()
            if existing:
                cursor.close()
                flash('IA settings already exist for this academic year, course, and semester. Please edit the existing setup instead.', 'warning')
                return redirect(url_for('admin.ia_settings'))
            cursor.close()

            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO ia_settings
                (academic_year, course, semester, assignment_max, ia1_max, ia1_convert_to, ia2_max, ia2_convert_to, practical_enabled, practical_count, practical_max, total_marks)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            ''', (academic_year, course, semester, assignment_max, ia1_max, ia1_convert_to, ia2_max, ia2_convert_to, practical_enabled, practical_count, practical_max, total_marks))
            conn.commit()
            cursor.close()
        flash('IA settings saved successfully.', 'success')
        return redirect(url_for('admin.ia_settings'))
    return render_template('admin/ia_settings.html', ia_rows=fetch_all('SELECT * FROM ia_settings ORDER BY academic_year DESC, course ASC, semester ASC'), academic_years=fetch_all('SELECT label FROM academic_years ORDER BY label DESC'), courses=fetch_all('SELECT course_name FROM courses ORDER BY course_name ASC'))



@admin.route('/students')
@login_required
def students():
    academic_year = request.args.get('academic_year', '').strip()
    course = request.args.get('course', '').strip()
    semester = request.args.get('semester', type=int)
    search = request.args.get('search', '').strip()
    query = 'SELECT * FROM students WHERE 1=1'
    params = []
    if academic_year:
        query += ' AND academic_year = %s'; params.append(academic_year)
    if course:
        query += ' AND course = %s'; params.append(course)
    if semester:
        query += ' AND semester = %s'; params.append(semester)
    if search:
        query += ' AND (reg_no LIKE %s OR student_name LIKE %s)'; params.extend([f'%{search}%', f'%{search}%'])
    query += ' ORDER BY academic_year DESC, course ASC, semester ASC, reg_no ASC'
    students = fetch_all(query, params)
    return render_template('admin/students.html', students=students, has_filters=True, academic_years=fetch_all('SELECT label FROM academic_years ORDER BY label DESC'), courses=fetch_all('SELECT course_name FROM courses ORDER BY course_name ASC'), selected_year=academic_year, selected_course=course, selected_semester=semester, search_text=search)



@admin.route('/students/edit/<int:student_id>', methods=['GET', 'POST'])
@login_required
def edit_student(student_id):
    row = fetch_one('SELECT * FROM students WHERE id = %s', (student_id,))
    if not row:
        flash('Student not found.', 'error')
        return redirect(url_for('admin.students'))
    if request.method == 'POST':
        values = (request.form.get('academic_year', '').strip(), request.form.get('course', '').strip(), request.form.get('semester', type=int), request.form.get('reg_no', '').strip(), request.form.get('student_name', '').strip(), request.form.get('dob', '').strip(), request.form.get('section', '').strip(), student_id)
        if not all(values[:6]):
            flash('Please fill all required student fields.', 'error')
            return redirect(url_for('admin.edit_student', student_id=student_id))
        with get_db() as conn:
            cursor = conn.cursor(dictionary=True)
            cursor.execute('SELECT id FROM students WHERE reg_no = %s AND id <> %s', (values[3], student_id))
            duplicate = cursor.fetchone()
            if duplicate:
                cursor.close()
                flash('Student register number already exists.', 'warning')
                return redirect(url_for('admin.edit_student', student_id=student_id))
            cursor.close()

            cursor = conn.cursor()
            cursor.execute('''UPDATE students SET academic_year = %s, course = %s, semester = %s, reg_no = %s, student_name = %s, dob = %s, section = %s WHERE id = %s''', values)
            conn.commit(); cursor.close()
        flash('Student updated successfully.', 'success')
        return redirect(url_for('admin.students'))
    return render_template('admin/edit_student.html', row=row, academic_years=fetch_all('SELECT label FROM academic_years ORDER BY label DESC'), courses=fetch_all('SELECT course_name FROM courses ORDER BY course_name ASC'))


@admin.route('/students/delete/<int:student_id>')
@login_required
def delete_student(student_id):
    try:
        affected = _delete_by_id('students', student_id)
        flash('Student deleted.' if affected else 'Student not found.', 'success' if affected else 'warning')
    except Exception as exc:
        flash(f'Could not delete student: {exc}', 'error')
    return redirect(url_for('admin.students'))


@admin.route('/upload_students', methods=['GET', 'POST'])
@login_required
def upload_students():
    if request.method == 'POST':
        file = request.files.get('file')
        academic_year = request.form.get('academic_year')
        course = request.form.get('course')
        semester = request.form.get('semester')
        if not all([academic_year, course, semester]):
            flash('Please select Academic Year, Course and Semester.', 'error')
            return redirect(url_for('admin.upload_students'))
        if not file or file.filename == '':
            flash('Please choose an Excel file.', 'error')
            return redirect(url_for('admin.upload_students'))
        try:
            df = normalize_student_dataframe(file)
        except Exception as exc:
            flash(str(exc), 'error')
            return redirect(url_for('admin.upload_students'))
        inserted = 0; updated = 0
        with get_db() as conn:
            cursor = conn.cursor(dictionary=True)
            for _, row in df.iterrows():
                cursor.execute('SELECT id FROM students WHERE reg_no = %s', (row['Register No'],))
                existing = cursor.fetchone()
                payload = (academic_year, course, int(semester), row['Student Name'], row['DOB'], row['Section'], row['Register No'])
                if existing:
                    cursor.execute('''UPDATE students SET academic_year = %s, course = %s, semester = %s, student_name = %s, dob = %s, section = %s WHERE reg_no = %s''', payload)
                    updated += 1
                else:
                    cursor.execute('''INSERT INTO students (academic_year, course, semester, reg_no, student_name, dob, section) VALUES (%s, %s, %s, %s, %s, %s, %s)''', (academic_year, course, int(semester), row['Register No'], row['Student Name'], row['DOB'], row['Section']))
                    inserted += 1
            conn.commit(); cursor.close()
        _flash_duplicate_or_saved('student record', duplicate_count=updated, inserted_count=inserted)
        return redirect(url_for('admin.students'))
    return render_template('admin/upload_students.html', academic_years=fetch_all('SELECT label FROM academic_years ORDER BY label DESC'), courses=fetch_all('SELECT course_name FROM courses ORDER BY course_name ASC'))


@admin.route('/students/template')
@login_required
def download_student_template():
    return send_file(build_student_template(), as_attachment=True, download_name='student_upload_template.xlsx', mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')


@admin.route('/teachers/template')
@login_required
def download_teacher_template():
    return send_file(build_teacher_template(), as_attachment=True, download_name='teacher_template.xlsx', mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')


@admin.route('/subjects/template')
@login_required
def download_subject_template():
    return send_file(build_subject_template(), as_attachment=True, download_name='subject_template.xlsx', mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')


@admin.route('/courses/template')
@login_required
def download_course_template():
    return send_file(build_course_template(), as_attachment=True, download_name='course_template.xlsx', mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')


@admin.route('/academic-years/template')
@login_required
def download_academic_year_template():
    return send_file(build_academic_year_template(), as_attachment=True, download_name='academic_year_template.xlsx', mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')



@admin.route('/courses/upload-excel', methods=['POST'])
@login_required
def upload_course_excel():
    file = request.files.get('file')
    if not file or file.filename == '':
        flash('Please choose a course Excel file.', 'error')
        return redirect(url_for('admin.courses'))
    try:
        df = pd.read_excel(file)
        df.columns = [str(col).strip().lower().replace(' ', '_') for col in df.columns]
        course_column = 'course_name' if 'course_name' in df.columns else df.columns[0]
        values = [str(v).strip() for v in df[course_column].tolist() if str(v).strip() and str(v).strip().lower() != 'nan']
        inserted = 0
        duplicates = 0
        with get_db() as conn:
            cursor = conn.cursor(dictionary=True)
            for course_name in values:
                cursor.execute('SELECT id FROM courses WHERE LOWER(course_name) = LOWER(%s)', (course_name,))
                if cursor.fetchone():
                    duplicates += 1
                    continue
                cursor.execute('INSERT INTO courses (course_name) VALUES (%s)', (course_name,))
                inserted += 1
            conn.commit()
            cursor.close()
        _flash_duplicate_or_saved('course', duplicate_count=duplicates, inserted_count=inserted)
    except Exception as exc:
        flash(f'Course upload failed: {exc}', 'error')
    return redirect(url_for('admin.courses'))


@admin.route('/subjects/upload-excel', methods=['POST'])
@login_required
def upload_subject_excel():
    file = request.files.get('file')
    if not file or file.filename == '':
        flash('Please choose a subject Excel file.', 'error')
        return redirect(url_for('admin.courses'))
    try:
        df = pd.read_excel(file)
        df.columns = [str(col).strip().lower().replace(' ', '_') for col in df.columns]
        inserted = 0
        duplicates = 0
        with get_db() as conn:
            cursor = conn.cursor(dictionary=True)
            for _, row in df.iterrows():
                academic_year = str(row.get('academic_year', '')).strip()
                course = str(row.get('course', '')).strip()
                semester = int(row.get('semester', 0) or 0)
                subject_code = str(row.get('subject_code', '')).strip()
                subject_name = str(row.get('subject_name', '')).strip()
                subject_type = str(row.get('subject_type', row.get('type', 'theory'))).strip().lower() or 'theory'
                if not all([academic_year, course, semester, subject_name]):
                    continue
                cursor.execute('''
                    SELECT id FROM subjects
                    WHERE academic_year = %s AND course = %s AND semester = %s AND LOWER(subject_name) = LOWER(%s)
                ''', (academic_year, course, semester, subject_name))
                if cursor.fetchone():
                    duplicates += 1
                    continue
                cursor.execute('''
                    INSERT INTO subjects (academic_year, course, semester, subject_code, subject_name, subject_type)
                    VALUES (%s, %s, %s, %s, %s, %s)
                ''', (academic_year, course, semester, subject_code, subject_name, subject_type))
                inserted += 1
            conn.commit()
            cursor.close()
        _flash_duplicate_or_saved('subject', duplicate_count=duplicates, inserted_count=inserted)
    except Exception as exc:
        flash(f'Subject upload failed: {exc}', 'error')
    return redirect(url_for('admin.courses'))


@admin.route('/promote_students', methods=['POST'])
@login_required
def promote_students():
    academic_year = request.form.get('academic_year', '').strip()
    course = request.form.get('course', '').strip()
    semester = request.form.get('semester', type=int)
    if not all([academic_year, course, semester]):
        flash('Academic year, course and semester are required for promotion.', 'error')
        return redirect(url_for('admin.students'))
    if semester >= 6:
        flash('Cannot promote beyond semester 6.', 'warning')
        return redirect(url_for('admin.students', academic_year=academic_year, course=course, semester=semester))
    with get_db() as conn:
        cursor = conn.cursor(); cursor.execute('UPDATE students SET semester = semester + 1 WHERE academic_year = %s AND course = %s AND semester = %s', (academic_year, course, semester)); count = cursor.rowcount; conn.commit(); cursor.close()
    flash(f'{count} students promoted to semester {semester + 1}.', 'success')
    return redirect(url_for('admin.students', academic_year=academic_year, course=course, semester=semester + 1))


def _build_report_query(academic_year='', course='', semester=None, subject_name=''):
    query = '''
        SELECT s.reg_no, s.student_name, s.academic_year, s.course, s.semester, im.subject_name,
               im.assignment_marks, im.ia1_marks, im.ia2_marks, im.ia1_converted, im.ia2_converted,
               im.practical_marks, im.grand_total, im.status
        FROM internal_marks im JOIN students s ON s.id = im.student_id WHERE 1=1
    '''
    params = []
    if academic_year:
        query += ' AND im.academic_year = %s'; params.append(academic_year)
    if course:
        query += ' AND im.course = %s'; params.append(course)
    if semester:
        query += ' AND im.semester = %s'; params.append(semester)
    if subject_name:
        query += ' AND im.subject_name = %s'; params.append(subject_name)
    query += ' ORDER BY im.academic_year DESC, im.course ASC, im.semester ASC, s.reg_no ASC'
    return query, params


@admin.route('/reports')
@login_required
def reports():
    academic_year = request.args.get('academic_year', '').strip()
    course = request.args.get('course', '').strip()
    semester = request.args.get('semester', type=int)
    subject_name = request.args.get('subject_name', '').strip()
    query, params = _build_report_query(academic_year, course, semester, subject_name)
    return render_template('admin/reports.html', data=fetch_all(query, params), academic_years=fetch_all('SELECT label FROM academic_years ORDER BY label DESC'), courses=fetch_all('SELECT course_name FROM courses ORDER BY course_name ASC'), subjects=fetch_all('SELECT DISTINCT subject_name FROM subjects ORDER BY subject_name ASC'), selected_year=academic_year, selected_course=course, selected_semester=semester, selected_subject=subject_name)


@admin.route('/reports/download/excel')
@login_required
def download_reports_excel():
    academic_year = request.args.get('academic_year', '').strip()
    course = request.args.get('course', '').strip()
    semester = request.args.get('semester', type=int)
    subject_name = request.args.get('subject_name', '').strip()
    query, params = _build_report_query(academic_year, course, semester, subject_name)
    rows = fetch_all(query, params)
    df = pd.DataFrame(rows)
    output = BytesIO()
    if df.empty:
        df = pd.DataFrame(columns=['reg_no', 'student_name', 'academic_year', 'course', 'semester', 'subject_name', 'assignment_marks', 'ia1_marks', 'ia2_marks', 'ia1_converted', 'ia2_converted', 'practical_marks', 'grand_total', 'status'])
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, sheet_name='Reports')
    output.seek(0)
    return send_file(output, as_attachment=True, download_name='imms_reports.xlsx', mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')


@admin.route('/reports/download/csv')
@login_required
def download_reports_csv():
    academic_year = request.args.get('academic_year', '').strip()
    course = request.args.get('course', '').strip()
    semester = request.args.get('semester', type=int)
    subject_name = request.args.get('subject_name', '').strip()
    query, params = _build_report_query(academic_year, course, semester, subject_name)
    rows = fetch_all(query, params)
    stream = StringIO()
    writer = csv.DictWriter(stream, fieldnames=['reg_no', 'student_name', 'academic_year', 'course', 'semester', 'subject_name', 'assignment_marks', 'ia1_marks', 'ia2_marks', 'ia1_converted', 'ia2_converted', 'practical_marks', 'grand_total', 'status'])
    writer.writeheader()
    for row in rows:
        writer.writerow(row)
    data = BytesIO(stream.getvalue().encode('utf-8'))
    data.seek(0)
    return send_file(data, as_attachment=True, download_name='imms_reports.csv', mimetype='text/csv')



@admin.route('/analytics')
@login_required
def analytics():
    avg = fetch_one('SELECT COALESCE(AVG(grand_total), 0) AS avg_marks FROM internal_marks')['avg_marks']
    subject_avg = fetch_all('''SELECT subject_name, AVG(grand_total) AS avg_marks, COUNT(*) AS entries FROM internal_marks GROUP BY subject_name ORDER BY subject_name ASC''')
    course_mix = fetch_all('SELECT course, COUNT(*) AS total_students FROM students GROUP BY course ORDER BY course ASC')
    return render_template('admin/analytics.html', avg=avg, subject_avg=subject_avg, course_mix=course_mix)
