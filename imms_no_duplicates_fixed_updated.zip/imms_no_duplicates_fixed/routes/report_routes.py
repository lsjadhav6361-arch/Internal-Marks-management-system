from flask import Blueprint, redirect, url_for

report = Blueprint('report', __name__, url_prefix='/report')


@report.route('/')
def index():
    return redirect(url_for('admin.reports'))
