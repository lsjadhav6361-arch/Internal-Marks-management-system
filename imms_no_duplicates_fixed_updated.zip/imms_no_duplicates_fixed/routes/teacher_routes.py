from io import BytesIO
from datetime import date

import pandas as pd
from flask import Blueprint, flash, redirect, render_template, request, send_file, session, url_for
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Spacer, Paragraph, Table, TableStyle

from database.db import fetch_all, fetch_one, get_db
from utils.auth import verify_password, hash_password
from services.marks_service import build_student_mark_payload

teacher = Blueprint("teacher", __name__, url_prefix="/teacher")


def require_teacher():
    if not session.get("teacher_id"):
        flash("Please log in as teacher.", "error")
        return False
    return True


def fetch_teacher_allocations(teacher_id):
    return fetch_all(
        """
        SELECT id, teacher_id, academic_year, course, semester, subject_name, created_at
        FROM teacher_allocations
        WHERE teacher_id = %s
        ORDER BY academic_year DESC, course ASC, semester ASC, subject_name ASC
        """,
        (teacher_id,),
    )


def fetch_students(academic_year, course, semester):
    return fetch_all(
        """
        SELECT id, academic_year, course, semester, reg_no, student_name, section
        FROM students
        WHERE academic_year = %s AND course = %s AND semester = %s AND is_active = 1
        ORDER BY reg_no ASC
        """,
        (academic_year, course, semester),
    )


def fetch_ia_settings(academic_year, course, semester):
    return fetch_one(
        """
        SELECT *
        FROM ia_settings
        WHERE academic_year = %s AND course = %s AND semester = %s
        LIMIT 1
        """,
        (academic_year, course, semester),
    )


def fetch_subjects_for_context(teacher_id, academic_year, course, semester):
    rows = fetch_all(
        """
        SELECT subject_name
        FROM teacher_allocations
        WHERE teacher_id = %s AND academic_year = %s AND course = %s AND semester = %s
        ORDER BY subject_name ASC
        """,
        (teacher_id, academic_year, course, semester),
    )
    return [row["subject_name"] for row in rows]


def fetch_saved_marks(teacher_id, academic_year, course, semester, subject_name):
    return fetch_all(
        """
        SELECT *
        FROM internal_marks
        WHERE teacher_id = %s
          AND academic_year = %s
          AND course = %s
          AND semester = %s
          AND subject_name = %s
        ORDER BY student_id ASC
        """,
        (teacher_id, academic_year, course, semester, subject_name),
    )


def fetch_student_query_map(teacher_id, academic_year, course, semester, subject_name):
    rows = fetch_all(
        """
        SELECT
            sq.id,
            sq.student_id,
            sq.subject_name,
            sq.query_text,
            sq.status,
            sq.created_at,
            sq.solved_at,
            t.name AS solved_by_name
        FROM student_queries sq
        JOIN students s ON s.id = sq.student_id
        JOIN teacher_allocations ta
          ON ta.teacher_id = %s
         AND ta.academic_year = s.academic_year
         AND ta.course = s.course
         AND ta.semester = s.semester
         AND ta.subject_name = sq.subject_name
        LEFT JOIN teachers t ON t.id = sq.solved_by_teacher_id
        WHERE s.academic_year = %s
          AND s.course = %s
          AND s.semester = %s
          AND sq.subject_name = %s
        ORDER BY sq.created_at DESC, sq.id DESC
        """,
        (teacher_id, academic_year, course, semester, subject_name),
    )
    query_map = {}
    for row in rows:
        query_map.setdefault(row['student_id'], row)
    return query_map




def fetch_teacher_students(teacher_id, academic_year='', course='', semester=None, search=''):
    query = """
        SELECT DISTINCT s.id, s.reg_no, s.student_name, s.academic_year, s.course, s.semester, s.section
        FROM students s
        JOIN teacher_allocations ta
          ON ta.academic_year = s.academic_year
         AND ta.course = s.course
         AND ta.semester = s.semester
        WHERE ta.teacher_id = %s
    """
    params = [teacher_id]

    if academic_year:
        query += " AND s.academic_year = %s"
        params.append(academic_year)
    if course:
        query += " AND s.course = %s"
        params.append(course)
    if semester:
        query += " AND s.semester = %s"
        params.append(semester)
    if search:
        query += " AND (s.reg_no LIKE %s OR s.student_name LIKE %s)"
        like = f"%{search}%"
        params.extend([like, like])

    query += " ORDER BY s.academic_year DESC, s.course ASC, s.semester ASC, s.reg_no ASC"
    return fetch_all(query, params)




def fetch_recent_student_queries(teacher_id, limit=8):
    return fetch_all(
        """
        SELECT
            sq.id,
            sq.student_id,
            sq.subject_name,
            sq.query_text,
            sq.status,
            sq.created_at,
            sq.solved_at,
            s.reg_no,
            s.student_name,
            s.academic_year,
            s.course,
            s.semester,
            s.section
        FROM student_queries sq
        JOIN students s ON s.id = sq.student_id
        JOIN teacher_allocations ta
          ON ta.teacher_id = %s
         AND ta.academic_year = s.academic_year
         AND ta.course = s.course
         AND ta.semester = s.semester
         AND ta.subject_name = sq.subject_name
        JOIN (
            SELECT student_id, subject_name, MAX(id) AS latest_id
            FROM student_queries
            WHERE status = 'pending'
            GROUP BY student_id, subject_name
        ) latest ON latest.latest_id = sq.id
        WHERE sq.status = 'pending'
        ORDER BY sq.created_at DESC
        LIMIT %s
        """,
        (teacher_id, limit),
    )


def count_pending_student_queries(teacher_id):
    row = fetch_one(
        """
        SELECT COUNT(*) AS total_count
        FROM (
            SELECT sq.student_id, sq.subject_name
            FROM student_queries sq
            JOIN students s ON s.id = sq.student_id
            JOIN teacher_allocations ta
              ON ta.teacher_id = %s
             AND ta.academic_year = s.academic_year
             AND ta.course = s.course
             AND ta.semester = s.semester
             AND ta.subject_name = sq.subject_name
            WHERE sq.status = 'pending'
            GROUP BY sq.student_id, sq.subject_name
        ) grouped_pending
        """,
        (teacher_id,),
    )
    return row['total_count'] if row and row.get('total_count') is not None else 0

def get_present_academic_year():
    today = date.today()
    start_year = today.year if today.month >= 6 else today.year - 1
    return f"{start_year}-{start_year + 1}"


def get_pretty_semester_options(existing_semesters):
    normalized = []
    seen = set()
    for value in list(existing_semesters) + list(range(1, 7)):
        try:
            sem = int(value)
        except (TypeError, ValueError):
            continue
        if sem not in seen and 1 <= sem <= 6:
            seen.add(sem)
            normalized.append(sem)
    return normalized

def calculate_dashboard_stats(teacher_id):
    allocations = fetch_teacher_allocations(teacher_id)

    stats = {
        "total_subjects": len(allocations),
        "total_students": 0,
        "marks_pending": 0,
        "marks_submitted": 0,
        "marks_confirmed": 0,
        "student_queries_pending": count_pending_student_queries(teacher_id),
    }

    total_students = fetch_one(
        """
        SELECT COUNT(DISTINCT student_id) AS total_students
        FROM internal_marks
        WHERE teacher_id = %s
        """,
        (teacher_id,),
    )
    if total_students and total_students.get("total_students") is not None:
        stats["total_students"] = total_students["total_students"]

    pending = fetch_one(
        """
        SELECT COUNT(*) AS total_count
        FROM internal_marks
        WHERE teacher_id = %s AND status = 'pending'
        """,
        (teacher_id,),
    )
    submitted = fetch_one(
        """
        SELECT COUNT(*) AS total_count
        FROM internal_marks
        WHERE teacher_id = %s AND status IN ('saved', 'submitted')
        """,
        (teacher_id,),
    )
    confirmed = fetch_one(
        """
        SELECT COUNT(*) AS total_count
        FROM internal_marks
        WHERE teacher_id = %s AND status = 'confirmed'
        """,
        (teacher_id,),
    )

    stats["marks_pending"] = pending["total_count"] if pending else 0
    stats["marks_submitted"] = submitted["total_count"] if submitted else 0
    stats["marks_confirmed"] = confirmed["total_count"] if confirmed else 0

    return stats


@teacher.route('/dashboard')
def dashboard():
    if not require_teacher():
        return redirect(url_for('login'))

    teacher_id = session['teacher_id']
    allocations = fetch_teacher_allocations(teacher_id)
    years = sorted({row['academic_year'] for row in allocations}, reverse=True)
    courses = sorted({row['course'] for row in allocations})
    semesters = get_pretty_semester_options({row['semester'] for row in allocations})
    stats = calculate_dashboard_stats(teacher_id)
    current_academic_year = get_present_academic_year()
    recent_queries = fetch_recent_student_queries(teacher_id, limit=8)

    return render_template(
        'teacher/dashboard.html',
        allocations=allocations,
        years=years,
        courses=courses,
        semesters=semesters,
        stats=stats,
        recent_queries=recent_queries,
        current_academic_year=current_academic_year
    )


@teacher.route('/select', methods=['GET', 'POST'])
def select_context():
    if not require_teacher():
        return redirect(url_for('login'))

    allocations = fetch_teacher_allocations(session['teacher_id'])
    years = sorted({row['academic_year'] for row in allocations}, reverse=True)
    courses = sorted({row['course'] for row in allocations})
    semesters = get_pretty_semester_options({row['semester'] for row in allocations})
    current_academic_year = get_present_academic_year()

    context = {}
    students = []
    ia = None
    subjects = []

    if request.method == 'POST':
        academic_year = (request.form.get('academic_year') or '').strip()
        course = (request.form.get('course') or '').strip()
        semester_text = (request.form.get('semester') or '').strip()
        context = {'academic_year': academic_year, 'course': course, 'semester': semester_text}

        if not academic_year or not course or not semester_text:
            flash('Please select academic year, course, and semester.', 'error')
        else:
            semester = int(semester_text)
            students = fetch_students(academic_year, course, semester)
            if not students:
                flash('No students found for the selected academic year, course, and semester.', 'error')

            ia = fetch_ia_settings(academic_year, course, semester)
            if not ia:
                flash('Internal mark settings are not configured by Admin for this selection.', 'error')

            if students and ia:
                subjects = fetch_subjects_for_context(session['teacher_id'], academic_year, course, semester)
                if not subjects:
                    flash('No subject allocation found for this teacher in the selected context.', 'error')

    return render_template(
        'teacher/select.html',
        allocations=allocations,
        years=years,
        courses=courses,
        semesters=semesters,
        context=context,
        students=students,
        ia=ia,
        subjects=subjects,
        current_academic_year=current_academic_year,
    )


@teacher.route('/marks-entry')
def marks_entry():
    if not require_teacher():
        return redirect(url_for('login'))

    academic_year = (request.args.get('academic_year') or '').strip()
    course = (request.args.get('course') or '').strip()
    semester = int((request.args.get('semester') or '0').strip() or 0)
    subject = (request.args.get('subject') or '').strip()

    students = fetch_students(academic_year, course, semester)
    if not students:
        flash('No students found for the selected academic year, course, and semester.', 'error')
        return redirect(url_for('teacher.select_context'))

    settings = fetch_ia_settings(academic_year, course, semester)
    if not settings:
        flash('Internal mark settings are not configured by Admin for this selection.', 'error')
        return redirect(url_for('teacher.select_context'))

    allowed_subjects = set(fetch_subjects_for_context(session['teacher_id'], academic_year, course, semester))
    if subject not in allowed_subjects:
        flash('You are not allocated to the selected subject.', 'error')
        return redirect(url_for('teacher.select_context'))

    saved_rows = fetch_saved_marks(session['teacher_id'], academic_year, course, semester, subject)
    saved_map = {row['student_id']: row for row in saved_rows}
    query_map = fetch_student_query_map(session['teacher_id'], academic_year, course, semester, subject)

    return render_template(
        'teacher/marks_entry.html',
        students=students,
        settings=settings,
        saved_map=saved_map,
        query_map=query_map,
        context={'academic_year': academic_year, 'course': course, 'semester': semester, 'subject': subject},
    )


@teacher.route('/approve-query/<int:query_id>', methods=['POST'])
def approve_query(query_id):
    if not require_teacher():
        return redirect(url_for('login'))

    academic_year = (request.form.get('academic_year') or '').strip()
    course = (request.form.get('course') or '').strip()
    semester = (request.form.get('semester') or '').strip()
    subject = (request.form.get('subject') or '').strip()

    row = fetch_one(
        """
        SELECT sq.id, sq.student_id, sq.subject_name
        FROM student_queries sq
        JOIN students s ON s.id = sq.student_id
        JOIN teacher_allocations ta
          ON ta.teacher_id = %s
         AND ta.academic_year = s.academic_year
         AND ta.course = s.course
         AND ta.semester = s.semester
         AND ta.subject_name = sq.subject_name
        WHERE sq.id = %s
        LIMIT 1
        """,
        (session['teacher_id'], query_id),
    )

    if not row:
        flash('Query not found for this teacher.', 'error')
    else:
        with get_db() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                UPDATE student_queries
                SET status = 'approved',
                    solved_at = NOW(),
                    solved_by_teacher_id = %s
                WHERE student_id = %s
                  AND subject_name = %s
                  AND status = 'pending'
                """,
                (session['teacher_id'], row['student_id'], row['subject_name']),
            )
            cursor.execute(
                """
                UPDATE internal_marks
                SET query_text = NULL
                WHERE student_id = %s
                  AND subject_name = %s
                """,
                (row['student_id'], row['subject_name']),
            )
            conn.commit()
        flash('Student query approved successfully.', 'success')

    redirect_target = (request.form.get('redirect_to') or '').strip()
    if redirect_target == 'view_marks' and academic_year and course and semester and subject:
        return redirect(url_for('teacher.view_marks', academic_year=academic_year, course=course, semester=semester, subject=subject))
    if academic_year and course and semester and subject:
        return redirect(url_for('teacher.marks_entry', academic_year=academic_year, course=course, semester=semester, subject=subject))
    return redirect(url_for('teacher.dashboard'))


@teacher.route('/save-marks', methods=['POST'])
def save_marks():
    if not require_teacher():
        return redirect(url_for('login'))

    academic_year = (request.form.get('academic_year') or '').strip()
    course = (request.form.get('course') or '').strip()
    semester = int((request.form.get('semester') or '0').strip() or 0)
    subject = (request.form.get('subject') or '').strip()

    students = fetch_students(academic_year, course, semester)
    settings = fetch_ia_settings(academic_year, course, semester)

    if not students:
        flash('No students found for the selected academic year, course, and semester.', 'error')
        return redirect(url_for('teacher.select_context'))

    if not settings:
        flash('Internal mark settings are not configured by Admin for this selection.', 'error')
        return redirect(url_for('teacher.select_context'))

    allowed_subjects = set(fetch_subjects_for_context(session['teacher_id'], academic_year, course, semester))
    if subject not in allowed_subjects:
        flash('You are not allocated to the selected subject.', 'error')
        return redirect(url_for('teacher.select_context'))

    errors = []
    payloads = []

    for student in students:
        payload, row_errors = build_student_mark_payload(student, request.form, settings)
        query_text = (request.form.get(f'query_{student["reg_no"]}') or '').strip()

        if row_errors:
            errors.extend(row_errors)
        else:
            payload['query_text'] = query_text
            payloads.append(payload)

    if errors:
        for err in errors[:8]:
            flash(err, 'error')
        if len(errors) > 8:
            flash(f'Plus {len(errors) - 8} more validation errors.', 'error')

        return redirect(url_for(
            'teacher.marks_entry',
            academic_year=academic_year,
            course=course,
            semester=semester,
            subject=subject
        ))

    with get_db() as conn:
        cursor = conn.cursor()
        for row in payloads:
            cursor.execute(
                """
                INSERT INTO internal_marks (
                    student_id, teacher_id, academic_year, course, semester, subject_name,
                    assignment_marks, ia1_marks, ia2_marks, practical_marks,
                    ia1_converted, ia2_converted, grand_total, query_text, status, source_type
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                ON DUPLICATE KEY UPDATE
                    teacher_id = VALUES(teacher_id),
                    assignment_marks = VALUES(assignment_marks),
                    ia1_marks = VALUES(ia1_marks),
                    ia2_marks = VALUES(ia2_marks),
                    practical_marks = VALUES(practical_marks),
                    ia1_converted = VALUES(ia1_converted),
                    ia2_converted = VALUES(ia2_converted),
                    grand_total = VALUES(grand_total),
                    query_text = VALUES(query_text),
                    status = VALUES(status),
                    source_type = VALUES(source_type)
                """,
                (
                    row['student_id'],
                    session['teacher_id'],
                    academic_year,
                    course,
                    semester,
                    subject,
                    row['assignment_marks'],
                    row['ia1_marks'],
                    row['ia2_marks'],
                    row['practical_marks'],
                    row['ia1_converted'],
                    row['ia2_converted'],
                    row['grand_total'],
                    row.get('query_text', ''),
                    'submitted',
                    'manual'
                ),
            )
        conn.commit()

    flash('Marks saved successfully.', 'success')
    return redirect(url_for(
        'teacher.view_marks',
        academic_year=academic_year,
        course=course,
        semester=semester,
        subject=subject
    ))


@teacher.route('/view-marks')
def view_marks():
    if not require_teacher():
        return redirect(url_for('login'))

    academic_year = (request.args.get('academic_year') or '').strip()
    course = (request.args.get('course') or '').strip()
    semester = int((request.args.get('semester') or '0').strip() or 0)
    subject = (request.args.get('subject') or '').strip()

    rows = fetch_saved_marks(session['teacher_id'], academic_year, course, semester, subject)
    students = {row['id']: row for row in fetch_students(academic_year, course, semester)}
    query_map = fetch_student_query_map(session['teacher_id'], academic_year, course, semester, subject)

    return render_template(
        'teacher/view_marks.html',
        rows=rows,
        students=students,
        query_map=query_map,
        context={'academic_year': academic_year, 'course': course, 'semester': semester, 'subject': subject}
    )


@teacher.route('/confirm-selected', methods=['POST'])
def confirm_selected():
    if not require_teacher():
        return redirect(url_for('login'))

    academic_year = (request.form.get('academic_year') or '').strip()
    course = (request.form.get('course') or '').strip()
    semester = int((request.form.get('semester') or '0').strip() or 0)
    subject = (request.form.get('subject') or '').strip()
    selected_ids = request.form.getlist('selected_rows')

    if not selected_ids:
        flash('Please select at least one row to confirm.', 'error')
        return redirect(url_for(
            'teacher.view_marks',
            academic_year=academic_year,
            course=course,
            semester=semester,
            subject=subject
        ))

    placeholders = ','.join(['%s'] * len(selected_ids))

    with get_db() as conn:
        cursor = conn.cursor()
        query = f"""
            UPDATE internal_marks
            SET status = 'confirmed',
                confirmed_at = NOW()
            WHERE teacher_id = %s
              AND academic_year = %s
              AND course = %s
              AND semester = %s
              AND subject_name = %s
              AND id IN ({placeholders})
              AND status IN ('saved', 'submitted', 'pending')
        """
        params = [session['teacher_id'], academic_year, course, semester, subject, *selected_ids]
        cursor.execute(query, params)
        affected = cursor.rowcount
        conn.commit()

    if affected > 0:
        flash(f'{affected} selected row(s) confirmed successfully.', 'success')
    else:
        flash('No rows were confirmed.', 'error')

    return redirect(url_for(
        'teacher.view_marks',
        academic_year=academic_year,
        course=course,
        semester=semester,
        subject=subject
    ))


@teacher.route('/confirm-all', methods=['POST'])
def confirm_all():
    if not require_teacher():
        return redirect(url_for('login'))

    academic_year = (request.form.get('academic_year') or '').strip()
    course = (request.form.get('course') or '').strip()
    semester = int((request.form.get('semester') or '0').strip() or 0)
    subject = (request.form.get('subject') or '').strip()

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
            UPDATE internal_marks
            SET status = 'confirmed',
                confirmed_at = NOW()
            WHERE teacher_id = %s
              AND academic_year = %s
              AND course = %s
              AND semester = %s
              AND subject_name = %s
              AND status IN ('saved', 'submitted', 'pending')
            """,
            (session['teacher_id'], academic_year, course, semester, subject),
        )
        affected = cursor.rowcount
        conn.commit()

    flash(f'All eligible marks confirmed. Total updated: {affected}', 'success')
    return redirect(url_for(
        'teacher.view_marks',
        academic_year=academic_year,
        course=course,
        semester=semester,
        subject=subject
    ))


@teacher.route('/download-template')
def download_template():
    if not require_teacher():
        return redirect(url_for('login'))

    academic_year = (request.args.get('academic_year') or '').strip()
    course = (request.args.get('course') or '').strip()
    semester = int((request.args.get('semester') or '0').strip() or 0)
    students = fetch_students(academic_year, course, semester)

    data = [
        {
            'USN': s['reg_no'],
            'Student Name': s['student_name'],
            'Assignment Marks': '',
            'IA1 Marks': '',
            'IA2 Marks': '',
            'Practical Marks': '',
            'Query': '',
        }
        for s in students
    ] or [{
        'USN': '',
        'Student Name': '',
        'Assignment Marks': '',
        'IA1 Marks': '',
        'IA2 Marks': '',
        'Practical Marks': '',
        'Query': '',
    }]

    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        pd.DataFrame(data).to_excel(writer, index=False, sheet_name='MarksTemplate')
    output.seek(0)

    filename = f'teacher_marks_template_{academic_year}_{course}_sem{semester}.xlsx'
    return send_file(
        output,
        as_attachment=True,
        download_name=filename,
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )


@teacher.route('/upload-excel', methods=['GET', 'POST'])
def upload_excel():
    if not require_teacher():
        return redirect(url_for('login'))

    allocations = fetch_teacher_allocations(session['teacher_id'])
    years = sorted({row['academic_year'] for row in allocations}, reverse=True)
    courses = sorted({row['course'] for row in allocations})
    semesters = get_pretty_semester_options({row['semester'] for row in allocations})

    if request.method == 'POST':
        academic_year = (request.form.get('academic_year') or '').strip()
        course = (request.form.get('course') or '').strip()
        semester = int((request.form.get('semester') or '0').strip() or 0)
        subject = (request.form.get('subject') or '').strip()
        file = request.files.get('file')

        students = fetch_students(academic_year, course, semester)
        settings = fetch_ia_settings(academic_year, course, semester)
        allowed_subjects = set(
            fetch_subjects_for_context(
                session['teacher_id'],
                academic_year,
                course,
                semester
            )
        )

        if not students:
            flash('No students found for the selected academic year, course, and semester.', 'error')
            return redirect(url_for('teacher.upload_excel'))

        if not settings:
            flash('Internal mark settings are not configured by Admin for this selection.', 'error')
            return redirect(url_for('teacher.upload_excel'))

        if subject not in allowed_subjects:
            flash('You are not allocated to the selected subject.', 'error')
            return redirect(url_for('teacher.upload_excel'))

        if not file or file.filename == '':
            flash('Please choose an Excel file.', 'error')
            return redirect(url_for('teacher.upload_excel'))

        try:
            df = pd.read_excel(file)
        except Exception as exc:
            flash(f'Unable to read Excel file: {exc}', 'error')
            return redirect(url_for('teacher.upload_excel'))

        required_columns = ['USN', 'Student Name', 'Assignment Marks', 'IA1 Marks', 'IA2 Marks']
        missing = [col for col in required_columns if col not in df.columns]
        if missing:
            flash(f"Missing required columns: {', '.join(missing)}", 'error')
            return redirect(url_for('teacher.upload_excel'))

        usn_series = df['USN'].astype(str).str.strip()
        if (usn_series == '').any():
            flash('Excel contains empty USN values.', 'error')
            return redirect(url_for('teacher.upload_excel'))

        dup_values = usn_series[usn_series.duplicated()].unique().tolist()
        if dup_values:
            flash(f'Duplicate student entry found in Excel for USN {dup_values[0]}', 'error')
            return redirect(url_for('teacher.upload_excel'))

        student_map = {str(s['reg_no']).strip(): s for s in students}
        errors, payloads = [], []

        for _, row in df.iterrows():
            usn = str(row.get('USN', '')).strip()
            if usn not in student_map:
                errors.append(f'{usn}: Student does not belong to selected academic year/course/semester.')
                continue

            row_data = {
                f'assignment_{usn}': row.get('Assignment Marks', ''),
                f'ia1_{usn}': row.get('IA1 Marks', ''),
                f'ia2_{usn}': row.get('IA2 Marks', ''),
                f'practical_{usn}': row.get('Practical Marks', 0),
            }

            payload, row_errors = build_student_mark_payload(student_map[usn], row_data, settings)
            if row_errors:
                errors.extend(row_errors)
            else:
                payload['query_text'] = str(row.get('Query', '')).strip()
                payloads.append(payload)

        if errors:
            for err in errors[:8]:
                flash(err, 'error')
            if len(errors) > 8:
                flash(f'Plus {len(errors) - 8} more validation errors.', 'error')
            return redirect(url_for('teacher.upload_excel'))

        with get_db() as conn:
            cursor = conn.cursor()
            for row in payloads:
                cursor.execute(
                    """
                    INSERT INTO internal_marks (
                        student_id, teacher_id, academic_year, course, semester, subject_name,
                        assignment_marks, ia1_marks, ia2_marks, practical_marks,
                        ia1_converted, ia2_converted, grand_total, query_text, status, source_type
                    ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    ON DUPLICATE KEY UPDATE
                        teacher_id = VALUES(teacher_id),
                        assignment_marks = VALUES(assignment_marks),
                        ia1_marks = VALUES(ia1_marks),
                        ia2_marks = VALUES(ia2_marks),
                        practical_marks = VALUES(practical_marks),
                        ia1_converted = VALUES(ia1_converted),
                        ia2_converted = VALUES(ia2_converted),
                        grand_total = VALUES(grand_total),
                        query_text = VALUES(query_text),
                        status = VALUES(status),
                        source_type = VALUES(source_type)
                    """,
                    (
                        row['student_id'],
                        session['teacher_id'],
                        academic_year,
                        course,
                        semester,
                        subject,
                        row['assignment_marks'],
                        row['ia1_marks'],
                        row['ia2_marks'],
                        row['practical_marks'],
                        row['ia1_converted'],
                        row['ia2_converted'],
                        row['grand_total'],
                        row.get('query_text', ''),
                        'submitted',
                        'excel'
                    ),
                )
            conn.commit()

        flash('Excel marks uploaded successfully. Please review and confirm selected rows.', 'success')
        return redirect(url_for(
            'teacher.view_marks',
            academic_year=academic_year,
            course=course,
            semester=semester,
            subject=subject
        ))

    return render_template(
        'teacher/upload_excel.html',
        allocations=allocations,
        years=years,
        courses=courses,
        semesters=semesters
    )


@teacher.route('/change-password', methods=['GET', 'POST'])
def change_password():
    if not require_teacher():
        return redirect(url_for('login'))

    if request.method == 'POST':
        current_password = (request.form.get('current_password') or '').strip()
        new_password = (request.form.get('new_password') or '').strip()
        confirm_password = (request.form.get('confirm_password') or '').strip()

        if not current_password or not new_password or not confirm_password:
            flash('Please fill all password fields.', 'error')
            return redirect(url_for('teacher.change_password'))

        if len(new_password) < 6:
            flash('New password must be at least 6 characters.', 'error')
            return redirect(url_for('teacher.change_password'))

        if new_password != confirm_password:
            flash('New password and confirm password do not match.', 'error')
            return redirect(url_for('teacher.change_password'))

        with get_db() as conn:
            cursor = conn.cursor(dictionary=True)
            cursor.execute(
                """
                SELECT id, phone, password
                FROM teachers
                WHERE id = %s
                """,
                (session['teacher_id'],)
            )
            teacher_row = cursor.fetchone()

            if not teacher_row:
                cursor.close()
                flash('Teacher account not found.', 'error')
                return redirect(url_for('teacher.dashboard'))

            # Validate current password using hashed check.  Also allow
            # legacy phone-as-password logins as a fallback.
            current_ok = False
            if teacher_row.get('password'):
                current_ok = verify_password(teacher_row['password'], current_password)
            if not current_ok and teacher_row.get('phone'):
                current_ok = (teacher_row['phone'] == current_password)

            if not current_ok:
                cursor.close()
                flash('Current password is incorrect.', 'error')
                return redirect(url_for('teacher.change_password'))

            # Store the new password as a salted hash
            new_hashed = hash_password(new_password)
            cursor.execute(
                """
                UPDATE teachers
                SET password = %s
                WHERE id = %s
                """,
                (new_hashed, session['teacher_id'])
            )
            conn.commit()
            cursor.close()

        flash('Password changed successfully.', 'success')
        return redirect(url_for('teacher.dashboard'))

    return render_template('teacher/change_password.html')


@teacher.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = (request.form.get('email') or '').strip()
        phone = (request.form.get('phone') or '').strip()
        new_password = (request.form.get('new_password') or '').strip()
        confirm_password = (request.form.get('confirm_password') or '').strip()

        if not email or not phone or not new_password or not confirm_password:
            flash('Please fill all fields.', 'error')
            return redirect(url_for('teacher.forgot_password'))

        if len(new_password) < 6:
            flash('Password must be at least 6 characters.', 'error')
            return redirect(url_for('teacher.forgot_password'))

        if new_password != confirm_password:
            flash('Passwords do not match.', 'error')
            return redirect(url_for('teacher.forgot_password'))

        from utils.auth import hash_password

        with get_db() as conn:
            cursor = conn.cursor(dictionary=True)
            cursor.execute(
                """
                SELECT id
                FROM teachers
                WHERE email = %s AND phone = %s
                """,
                (email, phone)
            )
            teacher_row = cursor.fetchone()

            if not teacher_row:
                cursor.close()
                flash('Invalid email or phone.', 'error')
                return redirect(url_for('teacher.forgot_password'))

            # Hash the new password before saving
            hashed_pw = hash_password(new_password)
            cursor.execute(
                """
                UPDATE teachers
                SET password = %s
                WHERE id = %s
                """,
                (hashed_pw, teacher_row['id'])
            )
            conn.commit()
            cursor.close()

        flash('Password reset successful! Login now.', 'success')
        return redirect(url_for('login'))

    return render_template('teacher/forgot_password.html')


@teacher.route('/export-excel')
def export_excel():
    if not require_teacher():
        return redirect(url_for('login'))

    academic_year = (request.args.get('academic_year') or '').strip()
    course = (request.args.get('course') or '').strip()
    semester = int((request.args.get('semester') or '0').strip() or 0)
    subject = (request.args.get('subject') or '').strip()

    rows = fetch_all(
        """
        SELECT *
        FROM internal_marks
        WHERE teacher_id = %s
          AND academic_year = %s
          AND course = %s
          AND semester = %s
          AND subject_name = %s
          AND status = 'confirmed'
        ORDER BY student_id ASC
        """,
        (session['teacher_id'], academic_year, course, semester, subject),
    )

    students = {row['id']: row for row in fetch_students(academic_year, course, semester)}
    data = []

    for row in rows:
        student = students.get(row['student_id'], {})
        data.append({
            'USN': student.get('reg_no', ''),
            'Student Name': student.get('student_name', ''),
            'Subject': subject,
            'Academic Year': academic_year,
            'Course': course,
            'Semester': semester,
            'Assignment Marks': row.get('assignment_marks', 0),
            'IA1 Marks': row.get('ia1_marks', 0),
            'IA2 Marks': row.get('ia2_marks', 0),
            'Practical Marks': row.get('practical_marks', 0),
            'IA1 Converted': row.get('ia1_converted', 0),
            'IA2 Converted': row.get('ia2_converted', 0),
            'Grand Total': row.get('grand_total', 0),
            'Query': row.get('query_text', ''),
            'Status': row.get('status', ''),
            'Confirmed At': row.get('confirmed_at', ''),
            'Source Type': row.get('source_type', ''),
        })

    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        pd.DataFrame(data).to_excel(writer, index=False, sheet_name='ConfirmedMarks')
    output.seek(0)

    filename = f'{subject}_{academic_year}_{course}_sem{semester}_confirmed_marks.xlsx'
    return send_file(
        output,
        as_attachment=True,
        download_name=filename,
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )


@teacher.route('/export-pdf')
def export_pdf():
    if not require_teacher():
        return redirect(url_for('login'))

    academic_year = (request.args.get('academic_year') or '').strip()
    course = (request.args.get('course') or '').strip()
    semester = int((request.args.get('semester') or '0').strip() or 0)
    subject = (request.args.get('subject') or '').strip()

    rows = fetch_all(
        """
        SELECT *
        FROM internal_marks
        WHERE teacher_id = %s
          AND academic_year = %s
          AND course = %s
          AND semester = %s
          AND subject_name = %s
          AND status = 'confirmed'
        ORDER BY student_id ASC
        """,
        (session['teacher_id'], academic_year, course, semester, subject),
    )

    students = {row['id']: row for row in fetch_students(academic_year, course, semester)}

    output = BytesIO()
    doc = SimpleDocTemplate(
        output,
        pagesize=A4,
        leftMargin=28,
        rightMargin=28,
        topMargin=28,
        bottomMargin=28,
    )

    styles = getSampleStyleSheet()
    story = [
        Paragraph("Internal Marks Report", styles["Title"]),
        Spacer(1, 8),
        Paragraph(f"<b>Academic Year:</b> {academic_year}", styles["Normal"]),
        Paragraph(f"<b>Course:</b> {course}", styles["Normal"]),
        Paragraph(f"<b>Semester:</b> {semester}", styles["Normal"]),
        Paragraph(f"<b>Subject:</b> {subject}", styles["Normal"]),
        Spacer(1, 12),
    ]

    table_data = [[
        "USN", "Student", "Assign", "IA1", "IA2", "Practical", "IA1 Conv", "IA2 Conv", "Total", "Status"
    ]]

    for row in rows:
        student = students.get(row['student_id'], {})
        table_data.append([
            str(student.get('reg_no', '')),
            str(student.get('student_name', '')),
            str(row.get('assignment_marks', 0)),
            str(row.get('ia1_marks', 0)),
            str(row.get('ia2_marks', 0)),
            str(row.get('practical_marks', 0)),
            str(row.get('ia1_converted', 0)),
            str(row.get('ia2_converted', 0)),
            str(row.get('grand_total', 0)),
            str(row.get('status', '')),
        ])

    table = Table(table_data, repeatRows=1, colWidths=[58, 110, 42, 38, 38, 48, 52, 52, 44, 54])
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#0f172a')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 8),
        ('ALIGN', (2, 1), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('GRID', (0, 0), (-1, -1), 0.35, colors.HexColor('#cbd5e1')),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f8fafc')]),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 8),
        ('TOPPADDING', (0, 0), (-1, 0), 8),
        ('BOTTOMPADDING', (0, 1), (-1, -1), 6),
        ('TOPPADDING', (0, 1), (-1, -1), 6),
    ]))
    story.append(table)

    if not rows:
        story.append(Spacer(1, 12))
        story.append(Paragraph("No confirmed marks available for PDF export.", styles["Normal"]))

    doc.build(story)
    output.seek(0)

    filename = f"{subject}_{academic_year}_{course}_sem{semester}_confirmed_marks.pdf"
    return send_file(output, as_attachment=True, download_name=filename, mimetype='application/pdf')


@teacher.route('/students')
def students_view():
    if not require_teacher():
        return redirect(url_for('login'))

    allocations = fetch_teacher_allocations(session['teacher_id'])
    years = sorted({row['academic_year'] for row in allocations}, reverse=True)
    courses = sorted({row['course'] for row in allocations})
    semesters = get_pretty_semester_options({row['semester'] for row in allocations})

    academic_year = (request.args.get('academic_year') or '').strip()
    course = (request.args.get('course') or '').strip()
    semester = int((request.args.get('semester') or '0').strip() or 0)
    search = (request.args.get('search') or '').strip()

    rows = fetch_teacher_students(session['teacher_id'], academic_year, course, semester or None, search)

    return render_template(
        'teacher/students.html',
        rows=rows,
        years=years,
        courses=courses,
        semesters=semesters,
        context={
            'academic_year': academic_year,
            'course': course,
            'semester': semester,
            'search': search,
        }
    )


@teacher.route('/analytics')
def analytics():
    if not require_teacher():
        return redirect(url_for('login'))

    allocations = fetch_teacher_allocations(session['teacher_id'])
    years = sorted({row['academic_year'] for row in allocations}, reverse=True)
    courses = sorted({row['course'] for row in allocations})
    semesters = get_pretty_semester_options({row['semester'] for row in allocations})

    academic_year = (request.args.get('academic_year') or '').strip()
    course = (request.args.get('course') or '').strip()
    semester = int((request.args.get('semester') or '0').strip() or 0)
    subject = (request.args.get('subject') or '').strip()

    top_rows = []
    bottom_rows = []
    subjects = []

    if academic_year and course and semester:
        subjects = fetch_subjects_for_context(session['teacher_id'], academic_year, course, semester)

    if academic_year and course and semester and subject:
        allowed_subjects = set(fetch_subjects_for_context(session['teacher_id'], academic_year, course, semester))
        if subject not in allowed_subjects:
            flash('You are not allocated to the selected subject.', 'error')
            return redirect(url_for('teacher.analytics'))

        # Fetch the top and bottom five students by grand_total.  Previously, these
        # queries only considered marks that were in the "confirmed" state.  This
        # prevented analytics from loading until a teacher explicitly confirmed marks,
        # which confused users.  To provide useful feedback earlier, we no longer
        # restrict by status – all available marks for the selected context are
        # considered.  You can reintroduce a status filter if your workflow
        # requires it.
        top_rows = fetch_all(
            """
            SELECT s.reg_no, s.student_name, im.grand_total
            FROM internal_marks im
            JOIN students s ON s.id = im.student_id
            WHERE im.teacher_id = %s
              AND im.academic_year = %s
              AND im.course = %s
              AND im.semester = %s
              AND im.subject_name = %s
            ORDER BY im.grand_total DESC, s.reg_no ASC
            LIMIT 5
            """,
            (session['teacher_id'], academic_year, course, semester, subject),
        )

        bottom_rows = fetch_all(
            """
            SELECT s.reg_no, s.student_name, im.grand_total
            FROM internal_marks im
            JOIN students s ON s.id = im.student_id
            WHERE im.teacher_id = %s
              AND im.academic_year = %s
              AND im.course = %s
              AND im.semester = %s
              AND im.subject_name = %s
            ORDER BY im.grand_total ASC, s.reg_no ASC
            LIMIT 5
            """,
            (session['teacher_id'], academic_year, course, semester, subject),
        )

    return render_template(
        'teacher/analytics.html',
        years=years,
        courses=courses,
        semesters=semesters,
        subjects=subjects,
        top_rows=top_rows,
        bottom_rows=bottom_rows,
        context={
            "academic_year": academic_year,
            "course": course,
            "semester": semester,
            "subject": subject,
        }
    )