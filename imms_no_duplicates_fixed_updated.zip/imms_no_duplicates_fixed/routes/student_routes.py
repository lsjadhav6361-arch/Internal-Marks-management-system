from io import BytesIO
from functools import wraps
from secrets import token_urlsafe

from flask import Blueprint, flash, redirect, render_template, request, session, url_for, send_file, make_response, jsonify
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from database.db import execute_write, fetch_all, fetch_one, get_columns, table_exists

student = Blueprint('student', __name__, url_prefix='/student')


def _student_session_active():
    return bool(session.get('student_id')) and session.get('user_role') == 'student'


def require_student(view_func):
    @wraps(view_func)
    def wrapper(*args, **kwargs):
        if not _student_session_active():
            flash('Please log in again to continue.', 'error')
            return redirect(url_for('student.login'))
        return view_func(*args, **kwargs)
    wrapper.__name__ = view_func.__name__
    wrapper.__doc__ = view_func.__doc__
    wrapper.__module__ = view_func.__module__
    return wrapper


def _students_select_fields():
    return ', '.join([
        'id', 'academic_year', 'course', 'semester', 'reg_no', 'student_name',
        'dob', 'section', 'is_active'
    ])


def _default_avatar():
    return '🧑‍🎓'


def _ensure_student_query_table():
    execute_write(
        """
        CREATE TABLE IF NOT EXISTS student_queries (
            id INT PRIMARY KEY AUTO_INCREMENT,
            student_id INT NOT NULL,
            subject_name VARCHAR(120) NULL,
            query_text TEXT NOT NULL,
            status VARCHAR(30) NOT NULL DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            solved_at TIMESTAMP NULL DEFAULT NULL,
            solved_by_teacher_id INT NULL DEFAULT NULL,
            CONSTRAINT fk_student_queries_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
            CONSTRAINT fk_student_queries_teacher FOREIGN KEY (solved_by_teacher_id) REFERENCES teachers(id) ON DELETE SET NULL
        ) ENGINE=InnoDB;
        """
    )


def _ensure_query_columns():
    _ensure_student_query_table()
    columns = set(get_columns('student_queries')) if table_exists('student_queries') else set()
    if 'subject_name' not in columns:
        execute_write("ALTER TABLE student_queries ADD COLUMN subject_name VARCHAR(120) NULL AFTER student_id")
        columns.add('subject_name')
    if 'solved_at' not in columns:
        execute_write("ALTER TABLE student_queries ADD COLUMN solved_at TIMESTAMP NULL DEFAULT NULL AFTER status")
        columns.add('solved_at')
    if 'solved_by_teacher_id' not in columns:
        execute_write("ALTER TABLE student_queries ADD COLUMN solved_by_teacher_id INT NULL DEFAULT NULL AFTER solved_at")
        columns.add('solved_by_teacher_id')


def _get_student_row():
    return fetch_one(
        f'SELECT {_students_select_fields()} FROM students WHERE id = %s AND is_active = 1',
        (session['student_id'],),
    )


def _get_marks_and_settings(student_row):
    marks = fetch_all(
        """
        SELECT
            subject_name,
            assignment_marks,
            ia1_marks,
            ia2_marks,
            practical_marks,
            ia1_converted,
            ia2_converted,
            grand_total,
            query_text,
            status,
            updated_at
        FROM internal_marks
        WHERE student_id = %s
          AND academic_year = %s
          AND course = %s
          AND semester = %s
        ORDER BY updated_at DESC, subject_name ASC
        """,
        (
            student_row['id'],
            student_row['academic_year'],
            student_row['course'],
            student_row['semester'],
        ),
    )

    settings = fetch_one(
        """
        SELECT assignment_max, ia1_max, ia1_convert_to, ia2_max, ia2_convert_to,
               practical_enabled, practical_max, total_marks
        FROM ia_settings
        WHERE academic_year = %s AND course = %s AND semester = %s
        LIMIT 1
        """,
        (student_row['academic_year'], student_row['course'], student_row['semester']),
    ) or {}
    return marks, settings


def _build_summary(marks, settings):
    subject_count = len(marks)
    total_scored = round(sum(float(row.get('grand_total') or 0) for row in marks), 2)

    computed_subject_max = round(
        float(settings.get('assignment_max') or 0)
        + float(settings.get('ia1_convert_to') or 0)
        + float(settings.get('ia2_convert_to') or 0)
        + (float(settings.get('practical_max') or 0) if int(settings.get('practical_enabled') or 0) == 1 else 0),
        2,
    )

    configured_total_marks = round(float(settings.get('total_marks') or 0), 2)
    subject_max = computed_subject_max if computed_subject_max > 0 else configured_total_marks
    configured_max_total = round(subject_count * subject_max, 2) if subject_count and subject_max > 0 else 0

    raw_percentage = (total_scored / configured_max_total) * 100 if configured_max_total > 0 else 0
    score_percentage = round(min(max(raw_percentage, 0), 100), 1) if subject_count else 0
    improvement_percentage = round(max(0, 100 - score_percentage), 1) if subject_count else 100

    if subject_count:
        if score_percentage >= 85:
            performance_label = 'Excellent'
            performance_message = 'Outstanding work. Keep maintaining this performance.'
            performance_color = 'text-emerald-600'
        elif score_percentage >= 70:
            performance_label = 'Very Good'
            performance_message = 'You are doing very well. A little more effort can take you higher.'
            performance_color = 'text-cyan-600'
        elif score_percentage >= 55:
            performance_label = 'Good'
            performance_message = 'Good progress. Keep practicing to improve further.'
            performance_color = 'text-blue-600'
        elif score_percentage >= 40:
            performance_label = 'Average'
            performance_message = 'You can do better with regular study and revision.'
            performance_color = 'text-amber-600'
        else:
            performance_label = 'Poor'
            performance_message = 'Your score is low right now. You need to work harder for better marks.'
            performance_color = 'text-rose-600'
    else:
        performance_label = 'No Marks'
        performance_message = 'Waiting for teacher entry.'
        performance_color = 'text-slate-400'

    return {
        'subject_count': subject_count,
        'grand_total': total_scored,
        'max_total': configured_max_total if configured_max_total > 0 else 0,
        'subject_max': subject_max,
        'average': score_percentage,
        'published_count': sum(1 for row in marks if str(row.get('status') or '').lower() == 'published'),
        'latest_update': marks[0]['updated_at'] if marks else None,
        'performance_label': performance_label,
        'performance_message': performance_message,
        'performance_color': performance_color,
        'scored_percentage': score_percentage,
        'remaining_percentage': improvement_percentage,
    }


def _get_student_queries(student_id):
    return fetch_all(
        """
        SELECT sq.id, sq.subject_name, sq.query_text, sq.status, sq.created_at, sq.solved_at, t.name AS solved_by_name
        FROM student_queries sq
        LEFT JOIN teachers t ON t.id = sq.solved_by_teacher_id
        JOIN (
            SELECT subject_name, MAX(id) AS latest_id
            FROM student_queries
            WHERE student_id = %s
            GROUP BY subject_name
        ) latest ON latest.latest_id = sq.id
        WHERE sq.student_id = %s
        ORDER BY sq.created_at DESC, sq.id DESC
        """,
        (student_id, student_id),
    )



@student.route('/bootstrap-session', methods=['POST'])
def bootstrap_session():
    if not _student_session_active():
        return jsonify({'ok': False}), 401

    if session.get('student_bootstrap_pending'):
        session['student_bootstrap_pending'] = False

    return jsonify({'ok': True})


@student.route('/force-expire', methods=['POST'])
def force_expire():
    session.clear()
    return jsonify({'ok': True})


@student.route('/login', methods=['GET', 'POST'])
def login():
    if _student_session_active():
        return redirect(url_for('student.dashboard'))

    if request.method == 'POST':
        academic_year = (request.form.get('academic_year') or '').strip()
        semester = (request.form.get('semester') or '').strip()
        reg_no = (request.form.get('reg_no') or '').strip().upper()
        password = (request.form.get('password') or '').strip()

        if not academic_year:
            flash('Please select academic year.', 'error')
            return redirect(url_for('student.login'))
        if not semester:
            flash('Please select semester.', 'error')
            return redirect(url_for('student.login'))
        if not reg_no:
            flash('Please enter register number / USN.', 'error')
            return redirect(url_for('student.login'))
        if not password:
            flash('Please enter password.', 'error')
            return redirect(url_for('student.login'))

        student_row = fetch_one(
            f"""
            SELECT {_students_select_fields()}
            FROM students
            WHERE academic_year = %s AND semester = %s AND reg_no = %s AND is_active = 1
            LIMIT 1
            """,
            (academic_year, semester, reg_no),
        )

        if not student_row:
            flash('Student record not found. Please contact Admin.', 'error')
            return redirect(url_for('student.login'))

        stored_password = str(student_row.get('dob') or '').strip()
        if stored_password != password:
            flash('Invalid credentials.', 'error')
            return redirect(url_for('student.login'))

        session.clear()
        session['student_id'] = student_row['id']
        session['student_reg_no'] = student_row['reg_no']
        session['student_name'] = student_row['student_name']
        session['display_name'] = student_row['student_name']
        session['user_role'] = 'student'
        session['student_browser_token'] = token_urlsafe(24)
        session['student_bootstrap_pending'] = True
        session.permanent = False
        flash('Student login successful.', 'success')
        return redirect(url_for('student.dashboard'))

    academic_years = fetch_all('SELECT label FROM academic_years WHERE is_active = 1 ORDER BY label DESC')
    return render_template('student/login.html', academic_years=academic_years)


@student.route('/dashboard', methods=['GET', 'POST'])
@require_student
def dashboard():
    student_row = _get_student_row()

    if not student_row:
        session.clear()
        flash('Your record is not available. Please contact Admin.', 'error')
        return redirect(url_for('student.login'))

    _ensure_query_columns()

    if request.method == 'POST':
        subject_name = (request.form.get('subject_name') or '').strip()
        query_text = (request.form.get('query_text') or '').strip()

        if not subject_name:
            flash('Please select the subject for your query.', 'error')
            return redirect(url_for('student.dashboard'))

        if not query_text:
            flash('Please write your query before submitting.', 'error')
            return redirect(url_for('student.dashboard'))

        mark_row = fetch_one(
            """
            SELECT id
            FROM internal_marks
            WHERE student_id = %s
              AND academic_year = %s
              AND course = %s
              AND semester = %s
              AND subject_name = %s
            LIMIT 1
            """,
            (
                student_row['id'],
                student_row['academic_year'],
                student_row['course'],
                student_row['semester'],
                subject_name,
            ),
        )

        if not mark_row:
            flash('This subject mark is not available yet, so query cannot be sent now.', 'error')
            return redirect(url_for('student.dashboard'))

        execute_write("UPDATE internal_marks SET query_text = %s WHERE id = %s", (query_text, mark_row['id']))

        pending_query = fetch_one(
            """
            SELECT id
            FROM student_queries
            WHERE student_id = %s
              AND subject_name = %s
              AND status = 'pending'
            ORDER BY created_at DESC, id DESC
            LIMIT 1
            """,
            (student_row['id'], subject_name),
        )

        if pending_query:
            execute_write(
                "UPDATE student_queries SET query_text = %s, created_at = CURRENT_TIMESTAMP WHERE id = %s",
                (query_text, pending_query['id']),
            )
        else:
            execute_write(
                """
                INSERT INTO student_queries (student_id, subject_name, query_text)
                VALUES (%s, %s, %s)
                """,
                (student_row['id'], subject_name, query_text),
            )

        flash(f'Query submitted for {subject_name}. Your teacher can see it for this subject only.', 'success')
        return redirect(url_for('student.dashboard'))

    marks, settings = _get_marks_and_settings(student_row)
    student_queries = _get_student_queries(student_row['id'])
    summary = _build_summary(marks, settings)
    summary['query_count'] = len(student_queries)
    student_row['avatar_emoji'] = _default_avatar()

    return render_template(
        'student/dashboard.html',
        student=student_row,
        marks=marks,
        summary=summary,
        settings=settings,
        student_queries=student_queries,
    )


@student.route('/analytics')
@require_student
def analytics():
    student_row = _get_student_row()
    if not student_row:
        session.clear()
        flash('Your record is not available. Please contact Admin.', 'error')
        return redirect(url_for('student.login'))

    marks, settings = _get_marks_and_settings(student_row)
    summary = _build_summary(marks, settings)

    marks_sorted = sorted(marks, key=lambda row: str(row.get('subject_name') or ''))
    best_subject = max(marks_sorted, key=lambda row: float(row.get('grand_total') or 0), default=None)
    weak_subject = min(marks_sorted, key=lambda row: float(row.get('grand_total') or 0), default=None)

    subjects = [str(row.get('subject_name') or '') for row in marks_sorted]
    totals = [float(row.get('grand_total') or 0) for row in marks_sorted]
    assignments = [float(row.get('assignment_marks') or 0) for row in marks_sorted]
    ia1 = [float(row.get('ia1_converted') or 0) for row in marks_sorted]
    ia2 = [float(row.get('ia2_converted') or 0) for row in marks_sorted]
    practicals = [float(row.get('practical_marks') or 0) for row in marks_sorted]

    return render_template(
        'student/analytics.html',
        student=student_row,
        summary=summary,
        best_subject=best_subject,
        weak_subject=weak_subject,
        subjects=subjects,
        totals=totals,
        assignments=assignments,
        ia1=ia1,
        ia2=ia2,
        practicals=practicals,
    )


@student.route('/report-preview')
@require_student
def report_preview():
    student_row = _get_student_row()
    if not student_row:
        session.clear()
        flash('Your record is not available. Please contact Admin.', 'error')
        return redirect(url_for('student.login'))

    marks, settings = _get_marks_and_settings(student_row)
    summary = _build_summary(marks, settings)
    return render_template('student/report_preview.html', student=student_row, marks=marks, summary=summary)


@student.route('/export-pdf')
@require_student
def export_pdf():
    student_row = _get_student_row()
    if not student_row:
        session.clear()
        flash('Your record is not available. Please contact Admin.', 'error')
        return redirect(url_for('student.login'))

    marks, settings = _get_marks_and_settings(student_row)
    summary = _build_summary(marks, settings)

    output = BytesIO()
    doc = SimpleDocTemplate(output, pagesize=A4, leftMargin=28, rightMargin=28, topMargin=28, bottomMargin=28)

    styles = getSampleStyleSheet()
    title_style = ParagraphStyle('title_style', parent=styles['Title'], alignment=TA_CENTER, textColor=colors.HexColor('#0f172a'), fontSize=18, spaceAfter=6)
    sub_style = ParagraphStyle('sub_style', parent=styles['Normal'], alignment=TA_CENTER, textColor=colors.HexColor('#64748b'), fontSize=9, spaceAfter=14)
    section_style = ParagraphStyle('section_style', parent=styles['Heading2'], alignment=TA_LEFT, textColor=colors.HexColor('#0f172a'), fontSize=11, spaceAfter=8)

    story = [
        Paragraph('Student Marks Report', title_style),
        Paragraph('Internal Marks Management System (IMMS)', sub_style),
        Paragraph('Student Details', section_style),
    ]

    details_data = [
        [f"Name: {student_row.get('student_name', '')}", f"USN / Reg No: {student_row.get('reg_no', '')}"],
        [f"Academic Year: {student_row.get('academic_year', '')}", f"Course: {student_row.get('course', '')}"],
        [f"Semester: {student_row.get('semester', '')}", f"Section: {student_row.get('section') or '-'}"],
        [f"Total Scored: {summary['grand_total']}", f"Percentage: {summary['average']}%"],
    ]
    details_table = Table(details_data, colWidths=[260, 260])
    details_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), colors.white),
        ('BOX', (0, 0), (-1, -1), 0.6, colors.HexColor('#cbd5e1')),
        ('INNERGRID', (0, 0), (-1, -1), 0.35, colors.HexColor('#e2e8f0')),
        ('TEXTCOLOR', (0, 0), (-1, -1), colors.HexColor('#1e293b')),
        ('FONTSIZE', (0, 0), (-1, -1), 9),
        ('TOPPADDING', (0, 0), (-1, -1), 7),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 7),
    ]))
    story.extend([details_table, Spacer(1, 14), Paragraph('Marks Summary', section_style)])

    table_data = [['Subject', 'Assign', 'IA1', 'IA2', 'Practical', 'IA1 Conv', 'IA2 Conv', 'Total', 'Status']]
    for row in sorted(marks, key=lambda item: str(item.get('subject_name') or '')):
        table_data.append([
            str(row.get('subject_name', '')),
            str(row.get('assignment_marks', 0) or 0),
            str(row.get('ia1_marks', 0) or 0),
            str(row.get('ia2_marks', 0) or 0),
            str(row.get('practical_marks', 0) or 0),
            str(row.get('ia1_converted', 0) or 0),
            str(row.get('ia2_converted', 0) or 0),
            str(row.get('grand_total', 0) or 0),
            str(row.get('status', '') or ''),
        ])

    marks_table = Table(table_data, repeatRows=1, colWidths=[116, 42, 38, 38, 48, 50, 50, 42, 56])
    marks_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#0f172a')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 8),
        ('ALIGN', (1, 1), (-1, -1), 'CENTER'),
        ('ALIGN', (0, 0), (0, -1), 'LEFT'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('GRID', (0, 0), (-1, -1), 0.35, colors.HexColor('#cbd5e1')),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f8fafc')]),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 8),
        ('TOPPADDING', (0, 0), (-1, 0), 8),
        ('BOTTOMPADDING', (0, 1), (-1, -1), 6),
        ('TOPPADDING', (0, 1), (-1, -1), 6),
    ]))
    story.append(marks_table)

    if not marks:
        story.append(Spacer(1, 12))
        story.append(Paragraph('No marks available yet for PDF download.', styles['Normal']))

    doc.build(story)
    output.seek(0)

    reg_no = str(student_row.get('reg_no', 'student')).replace(' ', '_')
    filename = f"{reg_no}_{student_row.get('academic_year', '')}_{student_row.get('course', '')}_sem{student_row.get('semester', '')}_marks.pdf"
    return send_file(output, as_attachment=True, download_name=filename, mimetype='application/pdf')



@student.route('/main-login')
def main_login():
    session.clear()
    flash('Student session ended. Please log in again.', 'success')
    response = make_response(redirect(url_for('login')))
    response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '0'
    return response

@student.route('/logout')
def logout():
    session.clear()
    flash('Student logged out successfully.', 'success')
    response = make_response(redirect(url_for('student.login')))
    response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '0'
    return response
